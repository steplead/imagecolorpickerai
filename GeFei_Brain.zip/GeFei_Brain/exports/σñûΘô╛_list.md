# Search Results for "外链"
> Found 395 posts.

### 1. 8 年开发者经验分享&求职帖

10

loading...

2025-11-19 01:01

Chrome 插件

找需求

作品展示
- **Date:** 2025-11-18T17:01:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 用数据说话：今年注册了 9 个域名，只上线了 4 个，下面真实自己 三个游戏类网站，一个工具站，都没拿到结果，五月中旬加入社区 我发现第一个游戏站，3月份，纯练手， bffssummeraesthetic.com 没发任何外链，在五个月后来了流量，虽然很少 第二个双人游戏网站juegosde2.or...

### 2. 很多词都可以月入万刀，找不到词时可以放开限制，也许也可以试试高竞争关键词，瞄准一个词不断冲锋

1

哥飞

2025-11-25 03:54

内链

长尾词

关键词

找需求

找词
- **Date:** 2025-11-24T19:54:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** GeFei 抓瞎的雄 666 陈一crypto 牛逼 哥飞 大家来感受一下这位群友的实力，4月进群后，8月就实现了月入万刀。 Andy 不得了！ 拥抱自然 🐮 滴锥 牛的 六六 好像他是主做一个站然后一直站内优化和加外链吗 金智 厉害。 Chris_叨叨叨 都是大佬 Think tanshu 好奇...

### 3. 【2025.12.5案例拆解】paypal fee calculator

1

哥飞

2025-12-09 07:08
- **Date:** 2025-12-08T23:08:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** paypal fee calculator 一个小工具关键词，这种词的价值还是不错的 再发散一下，xx fee calculator 都能做。 像这类关键词，就是树枝状的，最大的的主干是 Calculator，往下有分为各种 xxx Calaulator ，如 Fee Calaulator，再往下还...

### 4. 如何免费使用浏览器自动化发外链？

6

萝卜丝

2025-12-12 02:19
- **Date:** 2025-12-11T18:19:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 操作步骤 下载插件AIPex https://chromewebstore.google.com/detail/aipex/iglkpadagfelcpmiidndgjgafpdifnke 这个插件是用来做浏览器自动化的，特点是你可以设置自己的大模型token 设置个人token 导航站来源 哥飞社...

### 5. 可以开始考虑每天搜索量10万以内，KD50到70的关键词了

2

哥飞

2024-07-20 14:21
- **Date:** 2024-07-20T06:21:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 今天的#哥飞小课堂 ，我们来看一个搜索量还挺大的词 ai face swap 和 face swap ai ，虽然看起来是两个词，并且搜索量实际是不一样的，但是因为意思相同，需求相同，并且谷歌趋势也把这两个词的热度值看成一样，所以我们也当作同一个词。 如果单纯看KD的话，会觉得有一定的难度，我们通常...

### 6. 【5800字长文】从网站站内优化到部署上线再到推广运营一篇文章让你学明白

30

哥飞

2024-08-13 03:50
- **Date:** 2024-08-12T19:50:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞，微信号 qiayue ，今天跟大家聊一下网站站内优化到部署上线再到推广运营一条龙，争取一篇文章让你学明白。 看这篇文章之前，需要先看前一篇挖掘需求的文章《出海工具网站，如何从需求挖掘到网站制作全流程》。 一、站内优化经验 我们通过分析需求，找到了我们可以做的关键词之后，就要思考，用...

### 7. 月访问量40万的SEO游戏站分析

1

哥飞

2024-08-13 08:13
- **Date:** 2024-08-13T00:13:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 上来先给大家看词，并且哥飞整理了前三名网站信息。 pokerogue.net 2024-02-25 注册，210个反链网站 pokerogue.io 2024-04-17 注册，270个反链网站 pokeroguegame.io 2024-05-08 注册，252个反链网站 以上三个网站，都不是群友...

### 8. 500 个外链拿下 $50K MRR

哥飞

2024-08-19 13:50

外链

外链建设

案例分享
- **Date:** 2024-08-19T05:50:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 刚才看数据，我大概估算了一下，群里某位朋友去年底开始做的网站，靠着勤勤恳恳加了差不多500个外链，现在拿下核心关键词搜索前几名了，保守估计MRR超过$50K。 按照我们前几天的算法，加一个外链MRR就增长100美元，这还是很划算的。 我知道有些朋友还不太习惯去加外链，总觉得是苦差事。 但是你要知道，...

### 9. 哥飞小课堂24.10.25 外链小课堂

2

彩笺

2024-10-25 11:54

外链建设
- **Date:** 2024-10-25T03:54:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 时间到，今天的#哥飞小课堂 跟大家聊聊怎么发外链。 发外链，很有用的一个策略就是抄作业。 其实很多地方都可以抄作业，挖需求可以抄作业，搞外链更是可以抄作业。 之前哥飞就在群里说法，找到能够发外链的地方的最好办法就是去找同行的网站抄作业，看看他们在哪些地方发了外链。 我们也可以去这些地方发。 具体怎么...

### 10. 谈谈失败案例，从中吸取经验

1

哥飞

2025-01-15 02:30

案例分享
- **Date:** 2025-01-14T18:30:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 之前总给大家讲成功案例，今晚#哥飞小课堂 给大家讲讲我们最近两个月的两个失败案例，还挺典型的，对大家会有一些帮助。 每次小课堂期间，在我讲完之前，大家先不要发言，听到有触动的，可以拍一拍我。 等我讲完了，会有问答环节，到时候大家再来问。 先说第一个失败案例 AISong.ai ，为什么说失败呢？ 大...

### 11. 分享一个找套壳网站的方法

1

哥飞

2025-01-15 08:13

网站数据

外链

数据分析
- **Date:** 2025-01-15T00:13:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 之前分享过通过看 checkout.stripe.com 的入站流量来分析不同网站的收入情况。 今天#哥飞小课堂 ，快速分享一个找套壳网站的方法。 拿 hf.space 来举例，在 Similarweb 可以看到所有给 hf.space 导入流量的网站。 这些网站有一部分是直接给 hf.space ...

### 12. 演示一下我平常怎么找词的

2

哥飞

2025-01-16 07:38

新词新站
- **Date:** 2025-01-15T23:38:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 这个站 elgoog.im，致力于把历年谷歌的一些彩蛋给复制过来，给大家随时体验。 2011年上线，至今已经有14年了，目前月访问量150万，72%访问量来自于谷歌搜索。 最近12个月里，月访问量最大到了213万。 很多内页，每个月都可以带来几千到几十万的访问量不等。 足够好玩，足够有趣，所有很多网...

### 13. 分享一个从媒体转型工具+媒体站的典型案例

2

哥飞

2025-01-17 07:52

案例分享
- **Date:** 2025-01-16T23:52:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** Ahrefs.com 通过免费工具策略，每年能够免费获取几百万上千万的访问量。 这些访问量，最终有一部分就可能转化为他的付费用户。 而且通过这些免费工具，还可以获得大量的外链。 （改正一下，刚才没注意到我选择的是12个月的数据） 这个才是按月的数据，拿12月来说，仅仅 backlink checke...

### 14. 聊聊放眼世界这个话题

哥飞

2025-01-17 08:04
- **Date:** 2025-01-17T00:04:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 朋友们，准备好小板凳上课了，今天的#哥飞小课堂 ，我们聊聊放眼世界这个话题。 我们常说要放眼看世界，那么目的是什么呢？ 当然是为了不坐井观天，不局限自己，让自己能够看到更大的世界，突破樊笼，提升认知。 在做的各位朋友们，能够进到这个群里，其实就已经比很多其他人更容易看到更大的世界了。 但是，我最近发...

### 15. 上站之后要做什么；再次详解谷歌搜索排名；以月收入$50k的网站为例说明

8

哥飞

2025-01-20 09:29
- **Date:** 2025-01-20T01:29:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 今天的#哥飞小课堂 ，我们聊聊如何基于数据驱动，做好上站之后的一些宣传推广工作。 很多朋友，刚开始做的几个网站，做的事情兴冲冲，做完就发现，怎么没流量呀？ 我今天就来告诉大家怎么排查问题，怎么基于数据驱动做事。 说是上站之后，是因为我默认大家做的网站，已经是做好了关键词研究工作，挖掘出来了有搜索量的...

### 16. 再次系统的聊聊如何判断一个关键词是否能做

19

哥飞

2025-01-22 10:27
- **Date:** 2025-01-22T02:27:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 今天的#哥飞小课堂 ，跟大家再次系统的聊聊，如何判断一个关键词是否能做。 开课之前，先跟大家征集一些关键词，等下我拿来做案例。 不用太多，几个就够。 好了，收集到足够多的数据了，今天挑前面10个来分析一下 aes encryption online stargate ai Playback Spee...

### 17. 跟大家聊聊 HTTP 协议、互联网、爬虫、外链。

哥飞

2025-02-27 09:15
- **Date:** 2025-02-27T01:15:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 预告一下，18:30 开始今天的#哥飞小课堂 ，跟大家聊聊 HTTP 协议、互联网、爬虫、外链。 看起来几个不相关的东西，其实对我们做网站很重要。 总有朋友问，为什么在Ahrefs看到了的外链，在GSC上看不到，其实原因就是因为爬虫还没爬到。 要解释为什么还没爬到，就需要解释互联网到底是个啥玩意儿。...

### 18. 再聊基于精品工具页面思路，如何做精品工具站

12

哥飞

2025-03-07 08:27

海量页面

高手分享

On-Page SEO

建议

工具
- **Date:** 2025-03-07T00:27:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 朋友们，周五下午好，好久没开#哥飞小课堂 了，今天我们继续完善精品工具页面思路。 之前我们聊的精品工具页面，详情看这个帖子 https://new.web.cafe/tutorial/detail/d2bbhguqe8 。 当时提到三个公式： 工具页+落地页+结果展示页=精品工具页面； 精品工具页面...

### 19. 一个找工具导航站的方法，用于提交自己的网站

8

阿威

2025-03-20 07:46
- **Date:** 2025-03-19T23:46:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 很多小伙伴做完了自己的工具站，都有找工具导航站来提交自己网站的需求，我这里分享一个方法给大家 我是阿威，我在六群，希望能跟大家多多交流 开门见山，就一句Google搜索语法 inurl:"submit" intext:"submit" AND "tool" intitle:"submit" AND ...

### 20. 详解落地页的V1.0到V1.5版本，再到V2.0版本

18

哥飞

2025-04-08 09:03
- **Date:** 2025-04-08T01:03:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，今天的#哥飞小课堂 给大家讲讲落地页的 1.0版本到1.5版本，以及我们目前正在用的2.0版本。 先直接给出定义： V1.0版本：工具页面+博客页面 V1.5版本：工具页面+落地页+博客页面 V2.0版本：精品工具页面=工具功能+落地页图文+工具生成结果列表 实际二十年前万兴科技刚出海时，探...

### 21. 学习维基百科内页和内链策略，做好我们自己的 AI 导航站

哥飞

2025-07-24 10:40

内链

反向链接

站点地图
- **Date:** 2025-07-24T02:40:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家周一下午好，预告一下，一会儿15点，久违的#哥飞小课堂 又开课了，这次跟大家聊聊维基百科的内页和内链设计。 我们做AI导航站，就特别适合学习借鉴这种模式。 聊维基百科内链之前，先跟大家聊聊品牌命名。 我们要如何给自己的产品命名，如果做一个有自己品牌名称的产品，而不是简单的用关键词做域名。 最典型...

### 22. 用关键词注册域名做的游戏站、工具站，后期如何横向拓展做大多强

4

哥飞

2025-07-24 11:39

找需求

找词

小游戏

案例分享
- **Date:** 2025-07-24T03:39:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，今天的#哥飞小课堂 开课了。 我们先从一个游戏热词开始说起，That's not my neighbor 这是2024年2月18日开始火起来的一个游戏，在3月底达到最高热度，之后降温，再到5月底又火了一次。 之后热度慢慢降低，直到现在，每天一万左右的搜索量。 用谷歌Ads关键词规划工具可以看...

### 23. 月访问量 270 万的音乐艺术家工具网站 Moises.ai，iOS App 预估月收入 60 万美元

哥飞

2025-08-04 07:27
- **Date:** 2025-08-03T23:27:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 看一个产品，Moises.ai ，给音乐艺术家用的工具产品。 2019年上线的，现在网站月访问量274万，26%流量来自于自然搜索，10%来自于付费搜索，56%来自于直接打开。 有iOS、Android双端App，也有桌面客户端。 iOS App 预估月收入60万美元，Android 则是20万美元...

### 24. 以月访问量 140 万的 imagecompressor.com 说明如何使用关键词注册域名，聚焦特定关键词，单点突破，拿下排名

4

哥飞

2025-08-04 09:05
- **Date:** 2025-08-04T01:05:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** imagecompressor.com 这个站，其实也算单页网站，虽然被谷歌收录了26个页面，但其实都是各个语言的翻译页面，实际每个语言就一个页面，也就是首页。 域名虽然是2004年注册的，实际网站上线于2018年6月，目前月访问量140万。 不过这类图片处理类网站，已经是特别特别卷了，每一个细分关...

### 25. 【哥飞小课堂】以 Venngage.com 为例讲解如何做好 GEO

2

哥飞

2025-08-07 02:50

GEO
- **Date:** 2025-08-06T18:50:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 看一个 AI 生成信息图的网站 venngage.com ，月访问量 140 万，70%流量来自于自然搜索。 这个网站会被拿出来当案例讲，是因为我看到他在 Ahrefs 统计的 AI 模型提及度很高，而且是各个模型都高。 换句话说，这个产品的 GEO 做得不错。 一个典型的提问是这样的，美国人问 I...

### 26. 【2025.4.29哥飞小课堂】Pixverse.ai SEO 反面案例拆解 ——6 大忌讳与新站实操启示

哥飞

2025-10-10 07:11

谷歌分析

经验

高手分享

建站技术

案例分享
- **Date:** 2025-10-09T23:11:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 我们来看一个案例，这个网站一年访问量6236万，从搜索引擎过来的就有2410万，占比38.63%。 但是这么多搜索来的流量，94%都是搜索品牌词过来的。 这就说明，这个网站的SEO其实做得不好，但是品牌强大，让大家愿意去搜索找到来使用。 换句话说，这个网站要是能够好好做一下SEO规划，网站流量有可能...

### 27. 【2025.4.2哥飞小课堂】新站 “曝光消失” 原因解析 + 谷歌排名机制与优化策略

哥飞

2025-10-10 09:38

google

谷歌分析

经验

高手分享
- **Date:** 2025-10-10T01:38:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 预告一下，一会儿15点，#哥飞小课堂 开讲，最近有几个群里朋友都问过的问题，新站为什么给了一点曝光和点击之后，就突然就没有了。 如果还有朋友也有新站有类似问题，可以参照我刚发的截图，去GSC截图最近3个月的数据，发出来。 按照日期看数据，会更明显。 果然算是大家遇到比较多的一种情况，简单收集一下，就...

### 28. 【2025.3.24哥飞小课堂】【案例拆解】playhop.com案例拆解 —— 年访问 1200 万 + 的游戏站增长逻辑与盈利测算

哥飞

2025-10-11 06:45

关键词

谷歌分析

经验

游戏

网站建设
- **Date:** 2025-10-10T22:45:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 好久没看游戏站了，我们看个游戏盒子网站 playhop.com 。 2015年注册的域名，实际网站上线于2023年6月。 网站上线到现在，也就才一年半多一些时间，目前月访问量已经达到了1200多万。在去年11月时曾经到达过1450万最高值。 这是怎么做到的？ 今天的哥飞小课堂，带着大家一期看一看这个...

### 29. 【2025.1.4哥飞小课堂】新词挖掘实操指南 —— 从词根搜索到快速上线，手把手复刻 “流量挖矿” 流程

1

哥飞

2025-10-11 11:06

找需求

找词

关键词

经验

需求挖掘
- **Date:** 2025-10-11T03:06:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 一个有着看起来很山寨首页的网站 tenor.com ，月访问量 2670万。 域名注册于1995年，不过其实最初是上线于2014年的Riffsy，2016年改名为Tenor，2018年被谷歌收购。 网站首页看起来没啥设计，不知道是不是谷歌已经忘记还有这个产品了。 而且对于谷歌来说，两千多万的访问量，...

### 30. 如何免费使用浏览器自动化发外链？

萝卜丝

2025-12-12 02:19
- **Date:** 2025-12-11T18:19:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 操作步骤 下载插件AIPex https://chromewebstore.google.com/detail/aipex/iglkpadagfelcpmiidndgjgafpdifnke 这个插件是用来做浏览器自动化的，特点是你可以设置自己的大模型token 设置个人token 导航站来源 哥飞社...

### 31. No Title
- **Date:** 2025-12-10T05:31:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好， 我是 6 群的圈圈。 感谢甜果果🍎🍊群友的反馈插件出现了不可用的情况。 当初我开发这个 Chrome 插件，主要是为了自用，默认使用了 Google AI Studio 的免费 API。 前两天，AI Studio 取消了免费额度，导致调用 API 时出现报错：“You exceede...

### 32. No Title
- **Date:** 2025-12-09T00:10:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 这个网站 stjegypt.com 只在埃及周边国家流行 比较有意思的点在于，60%的流量来自社交网络。 说明用户很喜欢分享这个网站的内容到社交网络。 回到刚才这个网站，60%流量来自于社交网络。 而这里70%来自于 linkedin。 也就是说，很多人愿意把这个网站的链接贴到 linkedin 上...

### 33. No Title
- **Date:** 2025-12-09T00:10:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 又发现一个可以看外链的网站 https://payhip.com/ 这个定价模式也有意思 甚至可以直接把他当作收款渠道 https://payhip.com/features/sell-digital-downloads...

### 34. No Title
- **Date:** 2025-12-08T23:15:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 给大家看个典型案例，外链先行，权重随后跟上，之后才是搜索流量增长。 这个站三个多月时间，做的事情就是持续不断的发外链，内页反倒是没上几个，所以谷歌只收录了几个页面，如果站长能够在发外链的同时持续上内页，也许流量会更高。 这个站瞄准的关键词 KD 很高，77 算是 Super Hard ，所以用了两个...

### 35. No Title
- **Date:** 2025-12-08T23:08:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** paypal fee calculator 一个小工具关键词，这种词的价值还是不错的 再发散一下，xx fee calculator 都能做。 像这类关键词，就是树枝状的，最大的的主干是 Calculator，往下有分为各种 xxx Calaulator ，如 Fee Calaulator，再往下还...

### 36. No Title
- **Date:** 2025-12-08T23:07:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 来自群友阿强的好消息，他的网站 skillsmp.com 同时拿到了 Claude 和 Langchain 官方博客的 Dofollow 外链。 这种高质量外链，花钱都买不来的，只能靠网站做好了，被别人主动添加。 看看这个界面，整体颜色搭配 UI 啥的都很舒服，而且内容也多，更重要的是，内容质量被官...

### 37. No Title
- **Date:** 2025-12-08T23:00:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 可以尝试把原词加进来 typo 当然不懂呀，把 typo 词当做你的品牌词 给大家看个典型案例，外链先行，权重随后跟上，之后才是搜索流量增长。 这个站三个多月时间，做的事情就是持续不断的发外链，内页反倒是没上几个，所以谷歌只收录了几个页面，如果站长能够在发外链的同时持续上内页，也许流量会更高。 这个...

### 38. No Title
- **Date:** 2025-12-05T01:20:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 域名即功能 说明很多人在社交网络分享 这就有意思了，主要社交网络是youtube，那么估计他做了机器人，@ 之后就给总结，之后回复总结链接 大方向没问题，里边每一步的小细节，你要自己走一遍，才有更深的体会 看上图，随便输入一个域名就有了啊 举例 is tiktok down 这个词，你就可以做啊 全...

### 39. No Title
- **Date:** 2025-12-04T05:32:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 据晚点公众号消息，彪哥的 Pollo.ai 拿到了 1400 万美元的融资，原文看这里： https://mp.weixin.qq.com/s/3_Ywtvjm09IEZzrLJ-HQ4w 。 其实 2023 年 12 月 9 日我们的首次线下分享交流会，彪哥就到场了，也给大家做了一个简短的分享，可...

### 40. No Title
- **Date:** 2025-12-03T19:49:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 这三个站，做的同一个关键词，分别 10月 21 日、23 日、25 日注册域名，虽然流量最大的的确是最早注册的，但是第二名是更晚注册的。 而且大家会发现，多个人做同一个关键词，其实大家都能拿到不错的量。 这就告诉我们，虽然别人已经提前几天上站了，但如果你发现这个关键词还行，你依然可以上站，晚几天没关...

### 41. No Title
- **Date:** 2025-12-01T18:13:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 又到了猜流量环节，大家可以猜猜看，一个首页是截图这样的网站，月访问量可能是多少？ 提示一下，还不少。 有不少爱打游戏的群友一看截图就知道是哪个网站，所以直接公布答案，liquipedia.net 网站月访问量 4786 万，很牛。 这网站全都是免费流量，自然搜索带来 65% 访问量，直接打开 31%...

### 42. No Title
- **Date:** 2025-12-01T01:22:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家可以猜猜看，这样一个提供各种足球小游戏的网站，每个月访问量大概是什么量级？ A. 小于100K B. 100K1M C. 1M5M D. 5M~10M E. 大于10M 正确答案是 D，futbol-11.com 是 2022 年5 月注册的域名，到现在也才三年半不到，目前月访问量 920 万。...

### 43. No Title
- **Date:** 2025-12-01T00:55:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 哥飞 2025年最后一个月了，这一年，你有哪些进步？请在群里回答。 吴优秀 赚得更多了点… 知道什么词可以赚到钱 Halun @吴优秀  xinz 实现了月入百刀 但还没实现日入百刀...继续加油 秦毅stay热情靠谱浪漫(发光早睡版) 有了进一步的勇气，当然也有对自己的现状的拷问和观望状态的转变，...

### 44. No Title
- **Date:** 2025-11-30T23:12:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 关于 KD 和 KGR，时不时有群友问，到底怎么理解这两个指标。 今晚开个简短#哥飞小课堂 ，给大家再解释一下。 先说KGR，这个指标是用来看网页供应量的。 KGR 引入 intitle 数量，就是为了看网页供应量是否充足。 有些关键词的 intitle 搜索结果数量很大，就说明很多网页直接标题里就...

### 45. No Title
- **Date:** 2025-11-28T00:16:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 只要你做得够早，活得够久，谷歌的小工具都只能屈居第二名。 derivative-calculator.net 域名注册于 2012 年2 月，目前月访问量 725K 。 说明还得有文化 这个网站 derivative-calculator.net 只做一件事情，帮你求导数，并且告诉你步骤，让你知道结...

### 46. No Title
- **Date:** 2025-11-27T23:48:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 今天我们的报名图片，是 AI Studio 里的 Gemini 3 Pro 生成的网页，之后我再用 Awesome Screenshot 对网页截图生成的图片。 里边有一个报名二维码，我最开始想到的是自己去草料生成一张二维码图片，然后在网页里引用并显示二维码图片。 没想到的是，Gemini 3 Pr...

### 47. No Title
- **Date:** 2025-11-27T01:20:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 月访问量 380 万 supercoloring.com 做的就是 coloring pages 这个关键词 有几个做了 大大小小流量的站都有，感觉这是一个长期需求。 域名也是2008年注册的 看这个网站的首页，学习别人怎么做首页 找CPC高且KD值低且有一定搜索量的词 我尝试定一个新的公式，用搜索...

### 48. No Title
- **Date:** 2025-11-26T02:04:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** https://coopwb.in/ ，7月份注册的域名， Similarweb 显示上个月访问量880万，Semrush 显示自然搜索流量1130万。 不过目前已经被谷歌K站了，Bing 的收录还在。 常规的，先在Similarweb查一下相关数据 流量是突发的，新注册的域名，突然就搞到了很多流量...

### 49. No Title
- **Date:** 2025-11-26T01:30:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 这个网站 coopwb.in 获得了3100多个域名带来的9200多个外链。 平均每个域名3个外链页面。 随便打开一个 best 域名，发现跳转到了 https://tymods-best.ngontinh24.com/article/painkiller-fact-vs-fiction-what-...

### 50. No Title
- **Date:** 2025-11-25T02:31:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 中国特色服务，这种直接百度搜索可以。 我之前用站长工具的，但是后来被下线了。 https://tool.chinaz.com/dnsce/ 又上线了 How long does it take to rank in Google? (A study by Ahrefs) Ahrefs 的一个研究，在...

### 51. No Title
- **Date:** 2025-11-25T00:31:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** slidesgo.com， google slides 主题和 powerpoint 模板网站，2018年注册的域名，现在月访问量1132万。 同类的几个，流量都没这个站大。 69%流量，也即是790万，来自于搜索引擎自然搜索。 Semrush 也显示有770万访问量来自于搜索引擎。 拥有4000万...

### 52. No Title
- **Date:** 2025-11-24T23:18:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 又一个 AI 媒体，2022年6月注册的域名 the-decoder.com ，9月上线的网站。 目前月访问量 57 万。 大部分流量来自于美国、德国、英国等。 63%流量来自于搜索引擎。 marktechpost.com 也是AI媒体，做了几年了，目前月访问量280万。 57%流量来自于搜索引擎。...

### 53. No Title
- **Date:** 2025-11-24T19:54:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** GeFei 抓瞎的雄 666 陈一crypto 牛逼 哥飞 大家来感受一下这位群友的实力，4月进群后，8月就实现了月入万刀。 Andy 不得了！ 拥抱自然 🐮 滴锥 牛的 六六 好像他是主做一个站然后一直站内优化和加外链吗 金智 厉害。 Chris_叨叨叨 都是大佬 Think tanshu 好奇...

### 54. No Title
- **Date:** 2025-11-24T18:55:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家一起给GPTsHunter.com链接就好 dragganaitool.com 的流量10月依然坚挺，没有下降太多。 70%流量来自于搜索引擎。 在 Semrush 可以看到这个站的每个内页的获取流量情况，我们可以分析他的内页，看看流量来源关键词是什么，看看这个关键词的谷歌趋势，如果依然还是平稳...

### 55. No Title
- **Date:** 2025-11-24T01:47:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** diffchecker.com 文本差异比对工具，月访问量152万 42%流量来自于搜索引擎，55%来自于直接访问。 有个特点，支持把比对结果生成url分享出去，如 https://www.diffchecker.com/bJTqkvmQ/ 而这些分享出去的链接，很有可能就会出现在别的网站上，这样就...

### 56. No Title
- **Date:** 2025-11-24T01:39:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** indiehackers.com 流量降了几十万了 GPT4 现在生成的一些小代码，直接就能用了 真的是加速开发，大家要用好GPT4 更具体一点，举个例子 瞧瞧我发现了什么？ 那就得看谷歌是否收录了你在博客平台发的文章，一样可以用 site 语法查看。 如果没有的话，如果你有一个谷歌爬虫经常来的域名...

### 57. No Title
- **Date:** 2025-11-24T01:10:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 拿第一个子域名来举例，给大家分享下如何分析一个站。 上线即巅峰，拿下164万访问量。 主要流量来自于日本和美国。 大部分流量来自于直接访问，排名第二的是外链，从搜索引擎来的比较少。 tkgames-develop.github.io/holo_watermelon 打开这个链接，发现直接跳转到了 h...

### 58. No Title
- **Date:** 2025-11-24T00:39:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** shortbread.ai 这个网站大部分流量来自于外链，主要来自于 https://www.ycombinator.com/companies/shortbread 用昨晚的方法看 theresanaiforthat.com ，可以看到哪些 AI 产品页面的访问量更高。 对，人性可以来流量，流量最...

### 59. No Title
- **Date:** 2025-11-22T05:38:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 从 5 月 22 日正式开始学习刘小排老师的深海圈课程，新手入门海外网站开发，到今天 11 月 22 日，AI 网站出海刚好半年。这个月网站目前收入 990.28 美元，不出意外的话，月底就可以破千刀了。如果加上 450 美元商单收入，已经超过千刀了。分享总结一下这半年来的心路历程，希望我们都可以继...

### 60. No Title
- **Date:** 2025-11-21T01:03:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 群友有个站28天从谷歌拿到了100K点击 你复制图片地址在浏览器里看看是否可以正常打开 你复制一张图片地址发群里 谷歌这里说无法加载资源，那么就是在爬虫爬的时候打不开。 会不会你的图片首次打开时有什么特殊处理 发现一个老牌科技博客媒体，做了20多年了。 https://arstechnica.com...

### 61. No Title
- **Date:** 2025-11-20T19:47:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 开源在线图片编辑器，仿 PS https://github.com/viliusle/miniPaint 大家看下下面两个网址的区别，第一个是原网址，第二个加了个网址加了个锚点 https://tkgames.jp/holo_watermelon.html https://tkgames.jp/ho...

### 62. No Title
- **Date:** 2025-11-20T01:34:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** https://aicolors.co/ 这个 AI 加持的配色工具做得真不错，可惜就是站长不太会搞流量。 不仅可以点击左边的一些经典配色，右侧立即看结果，还可以输入 prompt 生成你自己想要的颜色，并且立马显示给你看搭配效果。 谷歌只收录了三个页面，可以参考 colorhexa.com ，把每...

### 63. No Title
- **Date:** 2025-11-19T19:44:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大站不愧是大站，靠搜索能够带来一亿访问量。 看外链也能看到来是大站，有41.9万个网站给了1.6亿个外部链接。 更重要的是看引荐域名数量。 一个大站的主要流量页面构成 在海外，色情是不可避免的流量 同时，再次提醒我们，多语言必须要做。 而AI是新增长引擎，这些大站也在拥抱AI。...

### 64. No Title
- **Date:** 2025-11-19T19:36:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 再发下之前发过的： 这个技巧核心就是利用哥飞前几天分享的动态生成网页技巧。 有很多网站的里有跳出链接，而这个跳出链接可以通过网址里的url参数来控制。 如秋玉米网站，就有一个链接可以自己控制。 那我们就可以去找类似的可以通过参数控制的页面。 下面以秋玉米的页面来说明操作步骤： 1、打开秋玉米的 wh...

### 65. No Title
- **Date:** 2025-11-18T18:59:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 最后一小点付费部分，跟大家分享下。 打开 Semrush 看反链。 https://www.mydealz.de/gutscheine/blinkist-com 不太了解老外的习惯，但是从流量数据来看，在 mydealz.de 上面卖新人可用的优惠券，是很有效的拉新方式。 你的比喻是对的 注册后用免...

### 66. No Title
- **Date:** 2025-11-18T17:01:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 用数据说话：今年注册了 9 个域名，只上线了 4 个，下面真实自己 三个游戏类网站，一个工具站，都没拿到结果，五月中旬加入社区 我发现第一个游戏站，3月份，纯练手， bffssummeraesthetic.com 没发任何外链，在五个月后来了流量，虽然很少 第二个双人游戏网站juegosde2.or...

### 67. No Title
- **Date:** 2025-11-18T03:16:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 猜猜这个站，月访问量是多少？ 朋友们，很难想象，2024年了，2048游戏网站，居然还有400万每月的访问量。 2018年10月27日注册的域名 做了5年了，这个摇钱树啊 上线就有流量，然后几乎流量就没下降过多少，挺稳的的。 做网站，真的能够养老。 刚收到最新消息，这个站是群里某个朋友的朋友做的。 ...

### 68. No Title
- **Date:** 2025-11-18T01:02:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 这个站，是一位公众号读者做的，单月80万访问量增长 全靠公众号教的方法，看来我免费教得太多了 他相当于没有自己开发相关功能，而是借用了 crushonai的能力，跟我们 iframe hf space 一个意思 其实是寿命估算 计算你能活多少岁的 的确没啥意思，已经没热度了 但是对于 crushon...

### 69. No Title
- **Date:** 2025-11-17T23:17:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 夸克 quark.cn 流量好大呀，只有12%来自于自然搜索，30%+来自于外链和社交平台，55%来自于直接访问。 估计主要是网盘流量。 这种合作，估计夸克需要给钱给淘宝 牛 关系归关系，算账归算账 不同企业之间，需要算清帐...

### 70. No Title
- **Date:** 2025-11-17T01:00:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** emojis.sh 用的是开源代码，2023年10月注册的域名，后面几个月流量在涨，并且保持住了，目前每个月访问量三十多万。 不算小了。 靠搜索来的流量 主要靠搜索来的流量。 而能拿到排名，跟这200个外链网站有很大关系。 这个应该是原版，有67次代码提交记录 https://github.com/...

### 71. No Title
- **Date:** 2025-11-14T05:35:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 10 月中旬，我离开字节的第一天，给自己的网站更换域名。原因很简单：我一年前给网站选的域名带有“品牌词”。在 10 月份的时候，有群友因为域名被投诉整站下架，我突然意识到：如果我未来想长期运营这个网站，不换域名，就是在给自己埋雷。 离职的节点反而帮我做了一个更彻底的选择。于是，我开始执行一次几乎是“...

### 72. No Title
- **Date:** 2025-11-14T03:15:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** https://foxy.ai/explore https://www.gptgirlfriend.online/ 又看到一个“新”网站 everand.com ，域名是 2005 年注册的，但其实是2023年10启用的。 不过我看了暂时有点迷糊，没看出来流量从哪里来的。 这个网站背靠大公司，这个公...

### 73. No Title
- **Date:** 2025-11-14T01:43:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** later.com 月访问量266万 buffer.com 月访问量297万 两个都是社交媒体账号和内容管理分析平台，看他们做了些哪些关键词，会发现有意思的点。 用内容找到自己产品的潜在用户。 或者说，去分析自己的潜在用户可能会搜索哪些关键词，就去做内容获取相关流量，以吸引潜在用户进站。 这个结论是...

### 74. No Title
- **Date:** 2025-11-13T21:38:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 1. 操作步骤 去github下载playwright-mcp 这个chrome扩展： https://github.com/microsoft/playwright-mcp/releases ， 选择最新版本，手动安装即可。 在trae中手动添加mcp： {   ""mcpServers"": {...

### 75. No Title
- **Date:** 2025-11-13T02:50:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 这类关键词，能拿到谷歌排名第一的结果，网站都不简单。 打开 Similarweb 一看，果然不简单，月访问量2795万。 每年12月还会因为感恩节到元旦的一系列促销活动而出现流量上涨。 深圳公司 Aftership 也不错，在一些大搜索量关键词里都能排到前10。 aftership.com 月访问量...

### 76. No Title
- **Date:** 2025-11-13T01:41:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** aniwatchtv.to 单月新增1亿访问量。 感觉是 Ahrefs 的数据滞后了。 有高权重域名的可以试试加个内页，做 aniwatch 这个词，看看能不能拿到一点流量。 趁着混乱，我们也许也可以反代一个站 目前这些新域名普遍权重不高，外链不多...

### 77. No Title
- **Date:** 2025-11-13T00:11:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 一个纯前端工具站，满足特别小众的一个需求，基于图片生成 3D 旋转 Gif 图，月访问量36万。 https://www.3dgifmaker.com/ 看流量曲线很有意思，之前都不到20万的，23年12月直接就流量翻倍了，24年1月流量略有下降，但也比之前多。 23年11月，自然搜索流量 62K ...

### 78. No Title
- **Date:** 2025-11-12T02:30:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 这里我是“受害者”，谷歌搜索“SoraWebui”，又个用了开源代码的网站排名第三。 因为用的我的开源代码，他什么都没改 连 Canonical 都没改 这次SoraWebui 是一个很好的案例，短时间大量上线相似网站，谷歌的确会无法分清楚谁是正主。 所以现在如果谷歌语言设置是中文，其实排名第一的是...

### 79. No Title
- **Date:** 2025-11-11T23:56:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 刚测试了一下，https://lingojam.com/ 可以免登录做一个转换器，然后在简介里用 markdown 格式给自己产品加一个外链，不过是 nofollow 的。 最好是真的做一个可以使用的转换器，而不是随便乱填信息。 上面是有一个做 emoji 的网站做的例子 perchance.org...

### 80. No Title
- **Date:** 2025-11-11T22:52:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 上面这种才是高质量外链，链接的锚文字就是网站的主关键词。 https://parade.com/1116816/marynliles/fun-websites/ 这种文章介绍的有趣的网站，都可以去研究一下，流量多大，主要流量来源是什么，为什么大家愿意帮忙写文章传播，是否可以再做一个新网站来满足类似需...

### 81. No Title
- **Date:** 2025-11-11T19:41:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** pagepilot.ai 流量不大，但是一直在赚钱，而且赚得越来越多。 他的策略是SEO是辅助，广告则快速搞量，两者结合，所向披靡。 每个月花两万多广告费，主要打的关键词都是自己的品牌词，目的就是不让自己的品牌搜索流量被浪费掉。 怎么判断一个网站是否在赚钱呢，看出站流量里有没有支付渠道的域名。 如 ...

### 82. No Title
- **Date:** 2025-11-11T18:47:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 但是这个“垃圾站”每个月却有11亿的访问量，你说气人不气人。 所以，会包装自己很重要。 我虽然是图片搬运工，但我是说我是灵感收集站。 对的，这里我要打引号 内容再组织，这就是价值所在。 借助AI，进行内容再组织，成本比以前低很多，这是我们的机会。 现在，有很多开源模型，可以理解图片，把图片用文字描述...

### 83. No Title
- **Date:** 2025-11-11T00:55:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 跟大家分享下我的这个站，现在我之前能够拿到排名的关键词，被一个GPTs抢走了。 再一次说明，要想抢关键词，GPTs 真是个好方法。 因为 chat.openai.com 域名权重太高了。 所以我们布局关键词的时候，各种高权重域名下的能够让我们发内容去抢排名的页面，都要去做一下。 跟我们做单页网站去抢...

### 84. No Title
- **Date:** 2025-11-10T02:59:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** deviantart.com 域名注册于2000年，目前月访问量9766万，差不多一个亿了。 流量中39%，也就是3810万左右，来自于自然搜索。 域名权重很高，并且他们的艺术家个人资料页面，可以放dofollow链接，不过你需要花3.3美元/月加V才能放链接。 也就是说，你一年花40美元，就可以得...

### 85. No Title
- **Date:** 2025-11-09T23:36:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** Levelsio 的项目 TherapistAI.com ，一个基于 TG bot 实现的在线AI心理治疗师，每月订阅费用9.9美元，改成 Llama 3 之后，效果很好了。 相同的内容，放在了两个域名，又是违反SEO规则的，但居然新域名也有这么多收录。 对，新域名差外链 新域名 aisong.ai...

### 86. No Title
- **Date:** 2025-11-09T22:49:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 我们再看一个产品我们再看一个产品 StealthGPT ，这是一个生成“Undetectable AI Content”的AI工具，也就是说他生成出来的内容不太容易被AI检测工具检测出来。 在 IndieHackers 上公布出来的，被验证的收入是201K美元。 而这个网站的访问量目前才26.4万每...

### 87. No Title
- **Date:** 2025-11-09T22:49:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 🚀 SiteData — 一款帮你看清网站流量与广告关系的小插件 关键词： 网站流量查询 ｜ DR值 ｜ 关联网站反查 ｜ AdSense ｜ Google广告透明中心 💡 我为什么做这个？ 平时做网站或分析竞争对手时，总想知道： “这个站流量怎么样？”、“有没有在投广告？”、“是不是同一个人做...

### 88. No Title
- **Date:** 2025-11-09T22:48:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 而外部链接里99.9%流量都来自于 chat.openai.com ，所以我们就可以假设收银台页面在3月总共被打开了450万次，我们假设打开一次就是一个订单，也就是有450万个订单。 这里我再解释下，一般打开了 Stripe 的收银台页面，就是已经创建好订单了。用户打开这个订单后，有可能不输入任何信...

### 89. No Title
- **Date:** 2025-11-09T17:57:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** https://twitter.com/keywordian/status/1786850998213914629 birdzilla.com 经受住了谷歌算法更新，流量一直在增长。 有人用邮件形式采访了站长。 上面内容，仅供参考，他的网站做了那么久了，日积月累，靠着内容吸引到了用户，同时也被谷歌所...

### 90. No Title
- **Date:** 2025-11-07T20:01:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 开发项目的时候把好的提示词整理归纳--避免每次重复 工具站出海： 1.整理外链文档 可以先用飞书的多维表格来整理，整理一份外链库 2.有一套博客体系 可以自动发文章，同步到线上 【例如搭建一个织梦或者wordpress】 3.快速上线站点的基建 【github上传，vercel部署，dns解析，域名...

### 91. No Title
- **Date:** 2025-11-06T23:37:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 分享个案例， trendshift.io 去年10月注册的域名，虽然目前半年过去了，流量不是特别大，但是一直在增长中。 我喜欢他提供的徽章服务，如进入 SoraWebui 的页面统计页面，可以看到给发了徽章。这里如果他能够显示到底是哪一天的就更好了。 我在别的网站看到用了 trendshift.io...

### 92. No Title
- **Date:** 2025-11-06T19:15:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** ai room planner 这个词最近搜索量在增长，一度超过GPTs的热度。 这个网站实际2022年底就上线了，去年这个时候流量更大，现在反而流量更小了。 谷歌趋势热度也是去年7月最大，这次又几乎达到去年7月的最高热度了。 所以我就在好奇，为什么最近又火了。 今天之前，我也没有去查过。 现在，现...

### 93. No Title
- **Date:** 2025-11-06T18:44:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** privnote.com 一个网页版阅后即焚小工具，2018年开始做的，目前平均月访问量100万。 有 3.4K 外链网站，535K外链网页。...

### 94. No Title
- **Date:** 2025-11-06T18:40:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 谷歌搜索 faceless video 出来的是域名完美匹配关键词的网站 https://faceless.video/ 。 faceless.video 虽然5月流量有一些回落，但从长趋势来看，也是一直在涨的。出站流量第一是 Stripe ，也就是说这个网站也是在赚钱的。 所以我们的思路其实很简单...

### 95. No Title
- **Date:** 2025-11-06T17:22:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 给大家看个案例，关于九九乘法表这个关键词，cuemath.com 这个网站是如何做页面来拿下流量的。 https://www.cuemath.com/multiplication-tables/ https://www.cuemath.com/multiplication-tables/tables...

### 96. No Title
- **Date:** 2025-11-06T01:39:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 现在说第二个，这个网站是 ChatGPT4o.ai ，看下面的曲线，是不是跟上面的 AISong.ai 的曲线很相似？是的，这也是被惩罚了。 虽然这个网站收录数量不多，但也属于刚上线就有比较多页面。 而且这个站的页面还有一个特点，内容跟网站核心关键词GPT 4o没有任何关系。 看 ChatGPT4o...

### 97. No Title
- **Date:** 2025-11-05T19:32:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 上来先给大家看词，并且哥飞整理了前三名网站信息。 pokerogue.net 2024-02-25 注册，210个反链网站 pokerogue.io 2024-04-17 注册，270个反链网站 pokeroguegame.io 2024-05-08 注册，252个反链网站 先给两三分钟，大家先研究...

### 98. No Title
- **Date:** 2025-11-05T02:38:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** https://livid.v2ex.com/essays/2018/05/18/adsense-methods.html 继续给大家看案例，月访问量 922万的 thewordfinder.com ，2006年注册的域名，主打的需求是帮助玩家更容易玩各种单词游戏，如Scrabble、Literat...

### 99. No Title
- **Date:** 2025-11-05T02:23:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 看一个产品，Moises.ai ，给音乐艺术家用的工具产品。 2019年上线的，现在网站月访问量274万，26%流量来自于自然搜索，10%来自于付费搜索，56%来自于直接打开。 有iOS、Android双端App，也有桌面客户端。 iOS App 预估月收入60万美元，Android 则是20万美元...

### 100. No Title
- **Date:** 2025-11-04T23:49:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 在 ai face swap 的搜索结果里，我们看到了一个网站 aifaceswap.io ，域名注册于2024年2月19日，目前外链网站数量74个，DR才7，但的确不仅拿下首页了，还进入前五了。 从最近几个月的流量曲线可以看到，又是一条特别漂亮的曲线，而且每个月的增长率都比之前更高。 上线至今，3...

### 101. No Title
- **Date:** 2025-11-04T23:49:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 酷炫按钮，做工具站可以用得上。 https://animata.design/docs/button/ai-button 这个证言展示效果也还不错 https://animata.design/docs/container/scrolling-testimonials 这个库总共有40个组件，特色是...

### 102. No Title
- **Date:** 2025-11-04T22:28:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 之前分享过通过看 checkout.stripe.com 的入站流量来分析不同网站的收入情况。 今天#哥飞小课堂 ，快速分享一个找套壳网站的方法。 拿 hf.space 来举例，在 Similarweb 可以看到所有给 hf.space 导入流量的网站。 这些网站有一部分是直接给 hf.space ...

### 103. No Title
- **Date:** 2025-11-04T00:30:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 先给大家讲讲故事，去年九月到今年三月，我受邀到生财有术社群当了几次出海航海教练。 今天的案例网站 describepicture.org 就是去年12月航海（实际航海开始时间是元旦后）时，其中一名学员 Andy Leo 做出来的。 在航海的第三天，Andy Leo 经过朋友的提示，找到了解析图片这个...

### 104. No Title
- **Date:** 2025-11-03T23:32:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 给大家看一个案例，一个卖定制化T恤、杯子、背包等礼品的网站，一年访问量1.05亿，7月访问量950万。 大家猜一猜，流量怎么来的？ 如果只是看官网，你会发现，好简洁。 https://www.creator-spring.com/ 主要流量来自于社交平台，99%搜索流量的关键词是非品牌，这就特别奇怪...

### 105. No Title
- **Date:** 2025-11-03T22:28:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 再给大家看一个案例，同样也是2016年上线的站 pinetools.com，目前月访问量330万，71%流量来自于自然搜索。 这个站做了大量的小工具，还有很多是前端小工具，用来获取搜索流量。 类似于 merge images 这种词，直接靠着内页就拿到了第一名的排名。 这个词目前月搜索量16.5万，...

### 106. No Title
- **Date:** 2025-11-03T20:02:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 再给大家一个之前的51个关键词里不存在的词 reducer ，也有很多工具类产品需求。 reduceimages.com 一年访问量3683万，大家可以自己当作家庭作业去分析一下。 需求挖掘相关文章，也搬运了十几篇过来了。 https://new.web.cafe/tutorial/89afd4d0...

### 107. No Title
- **Date:** 2025-11-03T19:01:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 刚才看数据，我大概估算了一下，群里某位朋友去年底开始做的网站，靠着勤勤恳恳加了差不多500个外链，现在拿下核心关键词搜索前几名了，保守估计MRR超过$50K。 按照我们前几天的算法，加一个外链MRR就增长100美元，这还是很划算的。 我知道有些朋友还不太习惯去加外链，总觉得是苦差事。 但是你要知道，...

### 108. No Title
- **Date:** 2025-11-03T02:15:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 再看一个骚操作案例，https://webp-png.com/ 这个网站甚至没有自己做功能，而是 iframe 了 https://webptopng.com/ 这个网站。 webp to jpg 这个词月搜索量122万。 不过挺难做的，ezgif.com/webp-to-jpg 排在最前面，而 e...

### 109. No Title
- **Date:** 2025-11-03T00:23:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 给大家分享给免费 SVG 图标下载网站，开放许可，免费商用。 https://www.svgrepo.com/ 网站域名注册于2016年，目前月访问量197万，最近12个月访问量1965万。 从流量曲线来看，最近12个月，流量几乎都在增长。 66%流量来自于自然搜索。 有 6.5K 个网站给他加了外...

### 110. No Title
- **Date:** 2025-11-03T00:22:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 这个网站靠卖收费提交，每天至少收入720美元，多则一千多美金。 https://viesearch.com/ 他有两档套餐，图文收录28.84美元一个站，仅文字收录14.42美元一个站。 前者可以出现在首页上，后者只能出现在内页里，都给dofollow链接。 观察最新添加的网站列表，根据日期查看，每...

### 111. No Title
- **Date:** 2025-11-02T19:17:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 这个网站域名是 c2story.com ，上线于6月份，到现在也三个月时间了。 其实只看界面的话，这个网站UI还是挺漂亮的。 但是很多SEO细节，的确是没做好。 我们看下GSC数据，三个多月的时间，总共才拿到99个曝光，35个点击。 可以说几乎没曝光了。 原因是为什么呢？ 很重要的一点，网站内容没有...

### 112. No Title
- **Date:** 2025-11-02T19:17:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 看一个内容站案例，对于大家做导航站应该会有启发。 TechTarget这个网站有一个 WhatIS 栏目，可以理解为就是对一些科技名词进行解释。 https://www.techtarget.com/whatis/ 从截图可以看到，这个站做了大量页面，一个页面介绍一个名词。 流量大的页面，每个月可以...

### 113. No Title
- **Date:** 2025-11-02T19:08:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** scratch.mit.edu 是儿童可视化编程 Scratch 平台的官网，目前月访问量21.46万，最近12个月访问量3.13亿。 在这个网站的发现栏目，有大量的热门作品，都是用 Scratch 做出来的，可以在线使用的。 https://scratch.mit.edu/explore/proj...

### 114. No Title
- **Date:** 2025-11-02T19:04:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 分析别的网站的外链，是的确能够挖掘出一些获取外链的方式的。 昨天小课堂提到游戏站，截图这个就是一个典型的游戏站，专门为某个游戏注册一个域名，这个域名主页就是这个游戏，但同时列出更多游戏给用户玩，提升用户停留时间，降低跳出率。 https://thatsnotmyneighbor.org/ 这些站，几...

### 115. No Title
- **Date:** 2025-11-02T18:46:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 分享一个项目，号称能够用AI帮你智能剪辑视频，把横屏长视频剪成竖屏短视频，当作新视频发到短视频平台赚钱。 开源地址：https://github.com/SamurAIGPT/AI-Youtube-Shorts-Generator 包含以下五大功能： Video Download: Given a ...

### 116. No Title
- **Date:** 2025-10-31T02:29:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** bejson.com 从一年前的100万访问量增长到了现在的200万访问量了。 有着8.3K网站给他加了外链，这个数量的外链显然不是靠着站长自己去加的，而是网站真的对别人有用，别人自发的推荐，形成的外链。...

### 117. No Title
- **Date:** 2025-10-31T01:19:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 刚有群友提到 www.crazygames.com 这个小游戏大站。 月访问量5620万，他自己的品牌词都有每个月400万的搜索量。 我们刚好可以看下这个站的 URL 结构设计。 /c/xxx 是分类页面 /t/xxx 是关键词聚合页面 /game/xxx 是游戏详情页 拿关键词聚合页面来说，以 h...

### 118. No Title
- **Date:** 2025-10-31T01:18:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 6个月过去了，这个关键词的排名也变化了好多。 4月份当时我们分享，有人靠着一个GPTs就拿下来了第二名，半年后再看，现在前三都是首页了。 studymonkey.ai 9月流量12.6万，4月流量16.5万，下降了24%左右。 homeworkai.ai 3月才开始做的，现在拿下了关键词第一名，流量...

### 119. No Title
- **Date:** 2025-10-31T00:33:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 无聊的按钮网站，每个月563K访问量，点击按钮，把你带到一个有趣的网站。 https://www.boredbutton.com/ 我们可以自己去提交网站，不过最好确保你的网站“有趣” https://www.boredbutton.com/add 在一些整理向的博文里，会介绍这个网站，所以各种外链...

### 120. No Title
- **Date:** 2025-10-30T22:53:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 来一起看一个有趣的网站 picrew.me ，虽然看起来最近12个月流量呈现下跌趋势，但是9月访问量还是挺大的，1050万每个月。 最近12个月总访问量1.66亿，很牛了。 如果只看截图的话，看不太出来这是一个什么样的网站。 大家应该的都玩过网页捏脸小游戏，你可以选择头型、头发、眼睛、鼻子等等各种器...

### 121. No Title
- **Date:** 2025-10-30T19:51:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 周五的晚上，送给大家一句话，或者说，一种思维方式。 每一个给站长用的 SaaS 服务，都可以用来找到那些正在赚钱的网站。 因为只有真的赚钱了，才舍得去用哪些长期收费的服务。 那么，只要找到哪些服务是给站长做的，就能够顺藤摸瓜，找到更多的赚钱风向标。 举例，很多网站都会接入第三方的 Affiliate...

### 122. No Title
- **Date:** 2025-10-30T19:33:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** ice breaker games 给大家一个词，这个适合有耐心的人去做。 网站可以做成内容+工具形式。 有大量的长尾关键词，而且这些词的广告单价并不低。 竞争不算激烈，而且目前排名靠前的，基本是某些网站的内页，收集了几十上百个破冰游戏，图文形式，就满足需求了。 ice breaker games ...

### 123. No Title
- **Date:** 2025-10-29T19:42:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 最近一直有朋友问 Woy.ai 为什么流量下降，其实我之前群里说过，今天再聊一下。 原因就是被谷歌惩罚了，8月2日还有2.5万的曝光，8月3日就只剩250个曝光了，直接跌到了之前的百分之一。 惩罚的原因，我猜测是有太多来自于新网站的全站外链。 这些新网站，刚注册的域名，网站刚上线没几天，立马就在首页...

### 124. No Title
- **Date:** 2025-10-29T19:35:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 跟大家分享一个案例，这是一个 typo 词，两个单词组成的，其中一个词是另一个词的 typo 写法。 很多人搜索，然后又因为我做了这个站，于是更多人搜索了。 所以平均排名1.3名，拿到 Sitelinks 了，点击率特别高。 另外有趣的一点，第二名和第三名是同一个网站，一个首页，一个内页，这说明目前...

### 125. No Title
- **Date:** 2025-10-29T19:20:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** summit.im 这个网站目前月访问量三四万，31.85%来自于自然搜索。 所有无法统计来源的都会被算到直接打开。 外链是referrals 算是新人比较容易出的问题，我们群里大家就不要再踩坑了。...

### 126. No Title
- **Date:** 2025-10-29T00:38:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 搜索 sha256 ，这个网站的内页居然能够排到第二名 做的久，外链多，于是权重就提上来了 2019年开始做的，很多年了。 这样的聚合工具站有很多的。 国内做得比较成功的在线工具盒子 tool.lu 月访问量160万 我的意思是，这类网站，的确有需求，但是国内外，都已经有很多这类网站了，建议动手之前...

### 127. No Title
- **Date:** 2025-10-28T19:47:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** anythingtranslate.com 这个站，今年1月注册的域名，现在有770K的访问量，很牛啊。 谷歌收录了 23,400 个页面，4月才开始有一点点访问量，之后就一发不可收拾，同一个增速曲线起飞。 有一些关键词，仅靠内页，这个站都拿到sitelinks了 有意思的是，在这个词 fancy ...

### 128. No Title
- **Date:** 2025-10-28T19:32:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 无聊的周三下午，我们来学习一个无聊的网站 boredhumans.com 。 域名很直白，无聊的人类。 这个站月访问量56.5万，不算太高，56%流量来自于自然搜索。 另有 3.85%的外链和1.9%的社媒，证明用户会传播这个网站。 这个网站看不太出来SEO痕迹，做得很随心所欲，但却有不少页面，能够...

### 129. No Title
- **Date:** 2025-10-28T00:31:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 24年5月左右进的群，因为之前做过百度的，所以大多数还能理解。24年大部分时间还在做电商方面，医疗类，所以做站这块投入的时间也少。 瞎忙了一年，做的医疗项目进展也一般，忙，但是不赚钱，8月又静心下来回顾一下过程，经验是学了不少。 -- 先说说经验，注册了美国公司，但是一直注册水星银行下不来，发现应该...

### 130. No Title
- **Date:** 2025-10-27T19:42:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 海外日历行程安排网站 calendly.com ，有60万的域名外链，原因也是因为很多用户使用他的功能来安排自己的行程。 然后在自己的网站里放一个链接，用户点击按钮，打开日历页面，约时间。 https://maxun-website.vercel.app/ 网站上的 Book Demo 按钮，点击后...

### 131. No Title
- **Date:** 2025-10-27T18:58:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 这个站 elgoog.im，致力于把历年谷歌的一些彩蛋给复制过来，给大家随时体验。 2011年上线，至今已经有14年了，目前月访问量150万，72%访问量来自于谷歌搜索。 最近12个月里，月访问量最大到了213万。 很多内页，每个月都可以带来几千到几十万的访问量不等。 足够好玩，足够有趣，所有很多网...

### 132. No Title
- **Date:** 2025-10-26T22:49:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 在我8月关注到这个网站时，他的7月访问量才170万。 结果5个月之后的12月，就到了990万，增长迅猛啊。 我又想起之前我的即刻个人介绍里写的： 有人在无人关注的角落里偷偷赚钱， 而我帮大家看到这些角落里的机会。 这个站的外链域名数量也不算太多，338个而已。 周活从50万，变成40万了 看起来产品...

### 133. No Title
- **Date:** 2025-10-26T20:15:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 裁剪图片是 crop ，那么扩图就是 uncrop 了。 我之前用 https://clipdrop.co/uncrop 来扩图，后来不给免费之后，就没订阅了，因为只是偶尔用一下。 然后刚才去谷歌搜索 uncrop ，果然就找到了 https://www.uncrop.com/ ，排在了谷歌搜索第二...

### 134. No Title
- **Date:** 2025-10-26T19:32:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 好了，收集到足够多的数据了，今天挑前面10个来分析一下 aes encryption online stargate ai Playback Speed Calculator webp to png ai face swap flux ai pdf image to video ai ai imag...

### 135. No Title
- **Date:** 2025-10-26T19:18:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 上次子木讲的这个方法挺好的，看别人外链里的 Best Links 部分，这就是高权重的外链，然后去抄作业。 我这个用的是 Ahrefs 的 29美元一个月的版本，功能挺齐全的，大家可以试试。 如我在找 maker 相关关键词时，看到了一个词 tier list maker ，完全看不懂。 谷歌搜索，...

### 136. No Title
- **Date:** 2025-10-26T19:00:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 实际做过多年SEO的人才懂，处处是细节。 只会念叨内容为王，外链为皇的人，就只会念叨这两句了。 我有一个网站，这周才发现Bing没有收录。 于是就去做了一些事情，目前看来有一些效果了： 1. 提交到 Bing 站长后台 https://www.bing.com/webmaster/ 2. 加上 Si...

### 137. No Title
- **Date:** 2025-10-24T01:13:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 刚搜索一个关键词，看到了一个网站，然后发现这个站在做了一系列的相关网站，都发给大家看看。 easyhindityping.com 月访问量410万，2012年6月注册的域名。 easynepalityping.com 月访问量76万，2011年8月注册的域名。 easytamiltyping.com...

### 138. No Title
- **Date:** 2025-10-23T23:42:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 这个游戏其实就是拼图，但是放到了装修这个场景下，就有点好玩了 分享一个谷歌搜索高级语法技巧，以 dailos.ai 这个网站为例，如果我们想要找到有哪些网站提到了这个域名，就可以用下面这个搜索语法： "dailos.ai" -site:dailos.ai 如果是一个上线比较久的网站，你还可以指定时间...

### 139. No Title
- **Date:** 2025-10-23T23:29:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 这个网站 https://wisprflow.ai/ 做得好漂亮，就那种很有设计感，看起来很舒服，很大气的感觉。而不是别的网站一看就知道是开发者审美。大家可以学习一下。 上次我们分享过 fliphtml5.com ，月访问量1500多万，2013年开始做的，是一家广州的公司做的。 刚我又看到一个类似...

### 140. No Title
- **Date:** 2025-10-23T23:15:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家猜猜这个打开页面，就是一整屏黑色的单页网站，月访问量是多少？ 提示一下，不是特别大，但也不小。 blackscreen.app 有404个外链域名，共1300个外链。 答案是1月883K，过去12个月，访问量1068万。 40%流量来自于自然搜索，56%来自于直接打开，这两个加起来就是96%。 ...

### 141. No Title
- **Date:** 2025-10-23T22:54:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 谷歌搜索 buy so domain 如何在GA中看流量来源渠道。 关于不是有了外链，就一定能够拿到更靠前的排名，一个很好的例子。 blockblastsolver.com 注册于2024年9月1日，blockblastsolver.org 注册于2024年10月7日。 前者只有43个外链域名，DR...

### 142. No Title
- **Date:** 2025-10-23T19:50:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 一个月从这个关键词获取7万多访问量。 onlinegames.io 这个域名是2018年4月注册的，但网站是2020年8月上线的。 而查询域名历史，会发现早在2009年，这个域名就被人注册过，后来没续费而被删除。 onlinegames.io 这个域名有4100多个网站外链，DR 74 。 既然这些...

### 143. No Title
- **Date:** 2025-10-23T19:12:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 有朋友不了解博客评论外链怎么回事，我找了一个WP博客评论区截图给大家看看。 严格来说，用博客评论来搞外链，这是在给互联网创造垃圾信息。 但是，目前实践表明，这种方式获取的外链依然还有效，所以我们明知道不对，也会去做。 那么问题就变成了，怎么让自己的评论不那么垃圾了。 举例，你可以通过谷歌site语法...

### 144. No Title
- **Date:** 2025-10-23T18:43:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 一个PHP做的个人网站进化史，作者的介绍页面，写于2015年3月，刚好就是10年前。 而这个网站 fantasynamegenerators.com 是2012年上线的，现在月访问量 370万。 这里有一个dofollow外链，大家可以研究一下，怎么获取。...

### 145. No Title
- **Date:** 2025-10-23T00:40:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家猜猜看，这个首页这么朴素的网站，大概哪一年做的，月访问量大概多少？ A. 2005 年前，100万 B. 2010 年前，300万 C. 2015 年后，500万 D. 2020 年后，700万 回答 D 的朋友是不是之前研究过这个网站，或者刚刚偷偷看答案了。 正确答案是，这个域名2020年7月...

### 146. No Title
- **Date:** 2025-10-23T00:26:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** Home 全 部  【2025.2.7案例拆解】easyhindityping.com  哥飞  2025-10-24 09:13  【2025.2.8案例拆解】 dailos.ai 谷歌高级搜索技巧  哥飞  2025-10-24 07:42  【2025.2.9案例拆解】https://wisp...

### 147. No Title
- **Date:** 2025-10-23T00:16:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** blackbox.ai 这个站观察好久了，是一个AI套壳站，在12月最高冲到了1900万访问量。 那最大流量的12月数据来看，绝大多数搜索流量都来自于品牌词搜索。 那么，这就要问一个问题了，怎么做到品牌词有那么大搜索量的？ 谷歌趋势看相关品牌词热度，过去12个月也是呈上升趋势的，最高峰也是24年12...

### 148. No Title
- **Date:** 2025-10-22T01:32:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 测试了Claude的联网搜索能力，我让他整理AI视频网站，结果他不是直接去搜索AI Video等关键词，而是去搜索引擎里搜索“best AI video generation websites tools platforms 2025”。 所以，如果想要让我们的产品被Claude看见，就需要让我们的...

### 149. No Title
- **Date:** 2025-10-21T23:55:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 好久没看游戏站了，我们看个游戏盒子网站 playhop.com 。 2015年注册的域名，实际网站上线于2023年6月。 网站上线到现在，也就才一年半多一些时间，目前月访问量已经达到了1200多万。在去年11月时曾经到达过1450万最高值。 这是怎么做到的？ 今天的哥飞小课堂，带着大家一期看一看这个...

### 150. No Title
- **Date:** 2025-10-21T23:01:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 这是一个典型的，做老词网站流量增长曲线，需要靠时间的积累，慢慢来。 这是平均排名2.9的一个内页，专门针对某个关键词去做的，点击率25.4%。 基本上拿关键词注册域名的，再去覆盖的其他关键词，点击率都会比自己品牌词做域名的点击率高一些。 因为用户一眼能够从域名判断出来，这是相关性比较高的网页。 像豆...

### 151. No Title
- **Date:** 2025-10-21T22:57:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 昨晚给娃找学乘法的数学游戏，在谷歌搜索 Multiplication Math Games 。 第一、第三名都是同一个网站 multiplication.com 。 大家注意域名，直接用的是乘法的英文单词 multiplication 的 com 域名。 查这个词的KD，只看数字62，好像不算太难，...

### 152. No Title
- **Date:** 2025-10-21T18:52:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 虽然 AI Speech Generator 这个关键词的搜索量不大，但是 speechgenerator.co 在美国地区拿下了这个关键词的第一名，还是很牛的。 最关键的是，这是一个KD 83的词，而这个网站的外链域名数量才106个 这么少的外链，拿下这个关键词第一名，我觉得最重要原因是，他选择的...

### 153. No Title
- **Date:** 2025-10-21T17:58:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** makeemoji.com 这个站月访问量100K，一半流量来自于自然搜索，还有7.58%来自于外部链接。 不知道大家会不会好奇，别人为什么要给他倒流呢？ 违和的点，是我自己制造出来的，我截了广告里的头像，传上去了，生成了很多动图。 只是为了跟大家演示，这个网站的核心用途和玩法。 不是站长要去控制广...

### 154. No Title
- **Date:** 2025-10-21T02:13:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 看到这三个网站的流量，大家有何感想？ 这就是三个活生生的案例，大家可以去研究，他们的流量构成，他们的外链情况，他们的站内优化细节。 能够短时间拿到流量的网站，都是宝贵的学习榜样。...

### 155. No Title
- **Date:** 2025-10-21T00:29:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** myinstants.com 这个站不知道大家关注过没有，去年五月，访问量是578万，今年4月，访问量是880万。 一个看起来很简单且小众的网站，为什么有那么多人访问？ 相关性强的上下文，是大模型能够给出正确回答的关键。 Mem0 的这个服务挺有意思的，相当于外挂硬盘，把记忆存在这里，让多个AI都能...

### 156. No Title
- **Date:** 2025-10-20T23:28:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 刚发现一个很好用的 SVG 编辑器 https://boxy-svg.com/app ，我的需求是调整 Logo 的字间距，发现他可以选中一个字母后，上下左右调整位置，很好用。 然后又发现他有更新日志 https://boxy-svg.com/changelog ，昨天都还在更新，我就有了传播的动力...

### 157. No Title
- **Date:** 2025-10-20T06:52:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 前言 大家好，我是空弦。 我于 2025.5.31 从字节离职，离职后的第一个月我的第一个订阅站顺利开了一些单，当时飞哥邀请我写一个小复盘来介绍自己从 0 到 1 新手出海的经历。当时的我觉得没有总结出什么可复用的方法和足够 solid 的思考认知，最后还是麻烦了一下飞哥，飞哥通过我的即刻和平时的交...

### 158. No Title
- **Date:** 2025-10-20T02:40:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 开花和扎根，都重要，轮着做。 上内页和上外链，都重要，轮着做。 上新站和维护旧站，都重要，轮着做。 工作和休息，都重要，轮着做。 上班和副业，都重要，轮着做。 工作和陪伴家人，都重要，轮着做。 来看个网站，只被收录7个页面，月访问量接近百万，emojicopy.com 域名注册于2016年3月，同年...

### 159. No Title
- **Date:** 2025-10-20T01:18:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 如果敢显示，那就没人用了，做这种网站，首要条件就是不存储日志 是的，肯定不会有 很多年前，有人也问过我，秋玉米会不会存，我说不可能存储的，没必要 发现群友做的 cursor101.com ，用的是 Gitbase ，基于 Devtoolset 去改的。 https://gitbase.app/ ht...

### 160. No Title
- **Date:** 2025-10-19T22:38:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 小排老师之前提过，他会选择的方向之一，是在线测试类产品，直接向用户收钱的那种。 刚看到这个网站 myiq.com 的广告，发现最近三个月访问量从七十多万，增长到了一千多万，大家可以研究一下，流量从哪来的，怎么变现？ 大家可以思考一下，为什么 wafflegame.net 有71%，也就是540左右的...

### 161. No Title
- **Date:** 2025-10-19T20:46:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** https://list.ly/ 这个网站DR78，建立一个 list ，放自己的网站或者别人的网站，可以得到 nofollow 服务端渲染外链。 分享一个小技巧，在Similarweb看关键词时，如果最近28天（或最近1个月）的搜索量，比平均体量更大，就说名这个词的热度是呈上升趋势的。 如果相差很...

### 162. No Title
- **Date:** 2025-10-19T19:14:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** imagecompressor.com 这个站，其实也算单页网站，虽然被谷歌收录了26个页面，但其实都是各个语言的翻译页面，实际每个语言就一个页面，也就是首页。 域名虽然是2004年注册的，实际网站上线于2018年6月，目前月访问量140万。 不过这类图片处理类网站，已经是特别特别卷了，每一个细分关...

### 163. No Title
- **Date:** 2025-10-19T18:39:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 答案来了，月访问量178万 最近用的工具原因 昨天提的睡眠计算器，关键词就有词根calculator，而这个需求，好像并没有多少群里朋友挖掘出来，这说明什么呢？ 说明大家对于词根的使用还不够深入，目前大多数群友只是把词根当做刷新词的辅助，但其实还有更多老需求，竞争并没有那么激烈。 有朋友想知道我昨天...

### 164. No Title
- **Date:** 2025-10-19T18:38:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** Wordle2.io 这样的游戏站，上一个新词内页之后的流量变化曲线。 不同的词，竞争程度不一样，曲线也不一样。 GetImg.ai 这样的图片网站，怎么上工具页面？ 看看这些案例就能学到了。 我们很多朋友老是说，不知道要做什么关键词，那我告诉你，去抄作业就好了。 搞外链可以抄作业，上内页也可以抄作...

### 165. No Title
- **Date:** 2025-10-19T18:31:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** velog.io 韩国博客平台，人人都能注册账号写博客，月访问量520万，域名DR75。 最关键的是，文章里放的链接是后端渲染的 dofollow 链接，意味着什么，大家自己体会。 几乎都是韩国流量，如果你的网站想要拿下韩语排名，那么这种本土语言网站的外链就会很有作用。 再次印证我之前说的，老二想要...

### 166. No Title
- **Date:** 2025-10-16T19:08:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** https://www.addmusictovideo.com/ 看一个奇葩案例，有人专门为 Add Music to Video 这个关键词做了一个网站，注册了一家公司，做了一个App。 不过这个网站他没怎么经营的感觉，外链没几个，也没拿到排名，也没多少访问量。 倒是App的评价有5万个，这样看起...

### 167. No Title
- **Date:** 2025-10-16T19:00:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 2023年10月我们分享过的网站 wheelofnames.com，当时月访问量1040万，现在一年半过去了，增长到了1490万。 这么大体量情况下，还有得增长，还是很不错的。 过去12个月，大流量关键词列表。 为什么网站有这么大访问量？ 因为他拿到了这些关键词比较靠前的排名。 为什么这些关键词有搜...

### 168. No Title
- **Date:** 2025-10-16T18:18:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 看一个刚需产品 What is My IP ，人人都有查询我当前的IP是多少，归属地是哪里的需求，这个2000年做的网站，到现在已经活了25年了，每个月有1000万访问量。 典型工具站页面布局，一进来第一屏就显示工具，这里是直接把用户的IP，地址信息给展示出来了。 做的年头够久，积累起来的外链域名数...

### 169. No Title
- **Date:** 2025-10-16T18:05:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** Devin.ai 的开发商做了 DeepWiki.com 这个免费工具，来接触到更多的开发者。 而 Devin.ai 的潜在用户就是开发者。 通过这种方式，也是为了让自己的业务得到更多的曝光，从而带来转化。 从上面这几个案例就可以看到，其实有很多方法能够得到曝光，从而得到业务转化。 不同的平台有不同...

### 170. No Title
- **Date:** 2025-10-16T17:52:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 我们来看一个案例，这个网站一年访问量6236万，从搜索引擎过来的就有2410万，占比38.63%。 但是这么多搜索来的流量，94%都是搜索品牌词过来的。 这就说明，这个网站的SEO其实做得不好，但是品牌强大，让大家愿意去搜索找到来使用。 换句话说，这个网站要是能够好好做一下SEO规划，网站流量有可能...

### 171. No Title
- **Date:** 2025-10-16T00:28:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 公布答案，circlecropimage.com 2023 年 4 月注册域名，第一版上线于 2023 年 10 月，目前月访问量 162K。 60% 访问量来自于自然搜索，28% 来自于直接打开，两项加起来 88%。 另有 7% 来自于外链，这个指的研究一下。 在 Similarweb 看到，只有...

### 172. No Title
- **Date:** 2025-10-16T00:25:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 一家登山向导公司的官网 ultimatekilimanjaro.com，月访问量 323K。 比较有意思的是，他的流量很大一部分来自于写的大量跟野外、动物相关的博文。 看网页标题：The #1 Guide Company for Climbing Kilimanjaro 老外挺喜欢自称第一名，这里说...

### 173. No Title
- **Date:** 2025-10-16T00:08:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 我就发现，海外大流量网站，其实并不排斥在网站里放广告，不管这个网站是否提供收费服务，都有可能会放广告。 从这点可以推出，海外的网站用户群体，其实也不排斥广告。 不像我们国内某些人，看到别人网站有广告，就觉得这个网站十恶不赦。 刚才一段话，我写完了，结果发出来不见了，只能再重写一下了。 accuwea...

### 174. No Title
- **Date:** 2025-10-16T00:03:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 给大家看看，合成大西瓜的开发商，微伞游戏是如何做游戏的，一个玩法，套上不同的皮肤，就成为了不同的游戏。 大家玩一下这两个游戏，会发现，其实玩法是一样的 甚至于这个水果对对消，其实也是合成大西瓜的玩法结合乐消除玩法。 上次跟大家分享过，花了 $99 提交到 Toolify.ai ，后来回本了。 刚发现...

### 175. No Title
- **Date:** 2025-10-15T23:51:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 跟大家分享一个神奇网站，radio.garden 用 3D 地图形式，给大家展示了全球数千个广播。 如我定位到深圳，找到了龙岗广播。 radio.garden 2016 年发布，目前月访问量 650 万。 地球上的每一个光点，就是一家广播电台。 全球各种广播你随便听，完全免费。 网站靠广告盈利。 这...

### 176. No Title
- **Date:** 2025-10-15T23:37:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 这是哪位群友做的站 growagardencalculator.net ，月新增访问量 150 万+，表扬一下！ 出道即巅峰，只有 12 个外链，这就是新词的魅力。 站长去年 6 月底进群的，到现在一年多时间，参加了几次新词新站比赛。 然后这次抓住新词机会，快速上站，一个多月就拿到了 160 万访问...

### 177. No Title
- **Date:** 2025-10-15T23:24:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 看到个移动端优先原则设计的PPT 生成小工具 https://www.slidemake.com/ 。 月访问量 118K，55% 访问量来自于自然搜索，35% 来自于直接打开，这两个加起来是 90%。 还有 6% 来自于外链，3% 来自于社交媒体分享。 主要搜索关键词是 Slide Maker、S...

### 178. No Title
- **Date:** 2025-10-15T00:58:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 哥飞 最近越来越多朋友出单了，这是好事，说明大家都慢慢找到了出单的方法。 其实总结下来，无非就是以下几点： 1、找到有人愿意付费的需求； 2、做个网站满足这个需求； 3、通过 SEO 或者广告获取到流量，引导用户付费。 说起来简单，实际做起来也是简单的。 我想邀请群里【终于出单了】的朋友们来分享分享...

### 179. No Title
- **Date:** 2025-10-14T19:20:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 给大家看个例子 AI Video Generator 这个词的美国区排名，我好像磕松动了，开始有一点排名迹象了。 当然，这个例子也还不够好，因为暂时数据量太小了，不足以说明后面还能继续涨。 再看另一个关键词，这就比较明显了。 当然，这些数据，也跟谷歌最近的算法更新有关。 综合多个群友的反馈，这次更新...

### 180. No Title
- **Date:** 2025-10-14T17:56:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 昨天有位群友提到 merge-csv.com 这个网站，我去研究了一下，为什么他能拿到 Ahrefs 和 Shopify 的外链，很有意思。 这个站能够拿到这些大站外链的很重要原因是，拿到了核心关键词 merge csv 和 csv merger 的第一名。 所以，因果关系是，站长先做了csv合并工...

### 181. No Title
- **Date:** 2025-10-14T05:03:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 1. 做站前的准备 模板准备：确保有模板，可以快速构建工具站，每次优化一次模板。避免过度关注bug和垃圾数据，每次迭代会变得更好。 关键词选择：关注多种词汇，无论是新词、老词、大词还是小词，都要做。通过飞哥的建议，关注新站的注册转化率，大概20%左右，新站转化率可低至1%。所以，在没有出单时，先关注...

### 182. No Title
- **Date:** 2025-10-14T02:15:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** Optimizilla.com 301 跳转到了 ImageCompressor.com 而打开后者，显示的网站名称依旧是前者。 跳转这事发生在 2018 年，我试图是考证，但没找到有效信息，为什么当年要换域名，是发生了什么事情，出于什么考虑要换域名的。 不知道有没有群里的朋友了解的。 还有没对接过...

### 183. No Title
- **Date:** 2025-10-14T00:03:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 看看 creativemarket.com 上老外对虚拟产品的定价，我们可以学习到很多，要勇于定价，9.9 其实很便宜的，19.9 也没多少。 148 张高清png图片，卖25～33 美金，平均每张图片大概一块多人民币。 在这个网站开店要求还是有一些的，如需要你填写你的 behance 或者 dri...

### 184. No Title
- **Date:** 2025-10-13T23:15:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 上次有群友说他的 Adsense账号数据报告可以按照流量来源维度看数据了，当时估计还在灰度，我的账号当时没有，今天去看，有了。 截图是我所有网站过去几年不同来源渠道的网页千次展示收入数据排行榜。 流量价值最高的居然是 Bing 来的流量。 这个列表里出现了两个我没见过的 fmkorea.com 月访...

### 185. No Title
- **Date:** 2025-10-13T19:57:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 看到一个失误操作案例 turbolearn.ai 品牌升级，域名切换为 turbo.ai， 但是他们犯了个大错误， 虽然把老域名跳转到了新域名， 但没有在新网站标题里加上老的品牌名 Turbolearn AI ，而是只写了新的品牌名 Turbo AI。 一般来说，新老品牌过渡期，都需要在新品牌后面写...

### 186. No Title
- **Date:** 2025-10-13T19:38:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 这个有点牛，纯内容站 广告有点狠，首次打开就弹积分墙广告。 用的是 Adsense 的积分墙广告 测试出来了，这里设置为 0 ，的确会在用户第一次访问时就弹出积分墙广告。 8月 Stripe 入站数据已更新，Wplace 干到了第三名，太牛了。 https://seo.box/referring/ ...

### 187. No Title
- **Date:** 2025-10-13T17:26:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** pixelartvillage.com 这个网站流量从 7 月的 18.6 万，增长到了 8 月的 225 万。 有群友问，他去做个类似网站，是不是可以搞到流量？ 对于这个问题，哥飞在八月十五中秋节，给大家开个简短小课堂，讲一讲。 没想到吧，中秋节还有哥飞小课堂 遇到这类流量暴涨的网站，千万别太激动...

### 188. No Title
- **Date:** 2025-10-13T17:21:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** Home 全 部  【2025.10.6案例拆解】pixelartvillage.com  1  哥飞  2025-10-14 01:26  【2025.10.4案例拆解】Venice.ai  哥飞  2025-10-14 01:21  【2025.10.3案例拆解】bolt.new  哥飞  20...

### 189. No Title
- **Date:** 2025-10-12T18:28:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 给大家分享同一个站长的几个不同关键词网站。 第一个站 textfaces.com 月访问量 4.2K。 第二个站 textfancy.com 月访问量 53.6K 第三个站 textstyler.com 月访问量 1.2K 的确有大有小哈，大大小小都可以看，不是只能看大流量网站，可以思考下，为什么有...

### 190. No Title
- **Date:** 2025-10-12T18:22:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家可以跟着我一起打开谷歌搜索这个词 dreamy room ，看看.org 这个站排第几名，我这里是第三名。 大家还可以思考一下，为什么第 3的有 152K 访问量，但是第 5 的就只有9.4K 访问量。 感谢大家的截图，我看了下，org 这个站，第一第二第三都出现过，第二出现最多。 大家看下截图...

### 191. No Title
- **Date:** 2025-10-11T02:40:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** Ahrefs.com 通过免费工具策略，每年能够免费获取几百万上千万的访问量。 这些访问量，最终有一部分就可能转化为他的付费用户。 而且通过这些免费工具，还可以获得大量的外链。 （改正一下，刚才没注意到我选择的是12个月的数据） 这个才是按月的数据，拿12月来说，仅仅 backlink checke...

### 192. No Title
- **Date:** 2025-10-11T02:11:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 朋友们，准备好小板凳上课了，今天的#哥飞小课堂 ，我们聊聊放眼世界这个话题。 我们常说要放眼看世界，那么目的是什么呢？ 当然是为了不坐井观天，不局限自己，让自己能够看到更大的世界，突破樊笼，提升认知。 在做的各位朋友们，能够进到这个群里，其实就已经比很多其他人更容易看到更大的世界了。 但是，我最近发...

### 193. No Title
- **Date:** 2025-10-11T01:53:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 说是上站之后，是因为我默认大家做的网站，已经是做好了关键词研究工作，挖掘出来了有搜索量的关键词，并且围绕着关键词对应的需求做好了网站功能，并且每一个页面都是围绕着核心关键词去做的。 如果以上前提都没做好，你就需要去找找之前的小课堂内容去学习了。 在做好了以上的前提下，我们再来学习今天的小课堂。 小课...

### 194. No Title
- **Date:** 2025-10-11T01:40:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 🔗 【哥飞SEO教程】如何制作出SEO友好的网页？先从学习谷歌是如何理解我们网页开始 今天的内容，总共​2500字，够干的了。 我直接把上面这篇之前写的文章内容给复制过来。 谷歌是如何抓取我们的网页，并且如何理解网页的。 注意，下文哥飞会在不同的句子里用“网址”、“网页”、“链接”等不同描述，有时...

### 195. No Title
- **Date:** 2025-10-11T01:23:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 今天的#哥飞小课堂 ，跟大家再次系统的聊聊，如何判断一个关键词是否能做。 开课之前，先跟大家征集一些关键词，等下我拿来做案例。 不用太多，几个就够。 好了，收集到足够多的数据了，今天挑前面10个来分析一下 aes encryption online stargate ai Playback Spee...

### 196. No Title
- **Date:** 2025-10-11T00:48:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 想要知道是什么操作吗？ 新年过后第一次#哥飞小课堂 一会儿就开课，来先拍拍我，看看多少人在线。 春节过完了，大家陆续都开始开工了。 如果大家手里有一些有流量的网站就会发现，即使春节放假，也不耽误大家赚钱，属于是人歇站不歇，流量天天来，美元日日有。 所以出海赚美元，这绝对是我们过去一两年做出的最正确的...

### 197. No Title
- **Date:** 2025-10-11T00:33:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 预告一下，18:30 开始今天的#哥飞小课堂 ，跟大家聊聊 HTTP 协议、互联网、爬虫、外链。 看起来几个不相关的东西，其实对我们做网站很重要。 总有朋友问，为什么在Ahrefs看到了的外链，在GSC上看不到，其实原因就是因为爬虫还没爬到。 要解释为什么还没爬到，就需要解释互联网到底是个啥玩意儿。...

### 198. No Title
- **Date:** 2025-10-10T23:52:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 朋友们，周五下午好，好久没开#哥飞小课堂 了，今天我们继续完善精品工具页面思路。 之前我们聊的精品工具页面，详情看这个帖子 https://new.web.cafe/tutorial/detail/d2bbhguqe8 。 当时提到三个公式： 工具页+落地页+结果展示页=精品工具页面； 精品工具页面...

### 199. No Title
- **Date:** 2025-10-10T23:24:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** Home 全 部  【2025.3.11哥飞小课堂】【案例拆解】emojicombos.com ——2020 年后建站，月活 720 万的流量增长逻辑  哥飞  2025-10-11 07:24  谷歌分析 Google Ads 经验 高手分享 网站建设  【2025.3.24哥飞小课堂】【案例拆解...

### 200. No Title
- **Date:** 2025-10-09T23:44:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 有不少群友问我，要不要给工具站写博客。 其实博客页、工具落地页，做出来都是为了获得流量。 有流量了，才有可能带来转化。 但是一般工具页面转化效果更好，所以我们网站上线后，会先去做工具落地页。 但是工具功能类关键词数量总是有限的，所以我们就需要去做博客页面来承接一些更长尾的需求。 这个案例，就是利用平...

### 201. No Title
- **Date:** 2025-10-09T20:20:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家周一下午好，预告一下，一会儿15点，久违的#哥飞小课堂 又开课了，这次跟大家聊聊维基百科的内页和内链设计。 我们做AI导航站，就特别适合学习借鉴这种模式。 聊维基百科内链之前，先跟大家聊聊品牌命名。 我们要如何给自己的产品命名，如果做一个有自己品牌名称的产品，而不是简单的用关键词做域名。 最典型...

### 202. No Title
- **Date:** 2025-10-09T19:27:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 案例分析：月访问量从0到10万花了10个月，再涨到200万又花了11个月 https://new.web.cafe/tutorial/detail/7qzrnu5csg 昨天的公众号收费文章，可以免费看啦。 看下这个网站首页的流量变化你就发现，这个站其实坐了很久的冷板凳。 上线 2023/06/18...

### 203. No Title
- **Date:** 2025-10-09T19:10:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，今天的#哥飞小课堂 开课了。 我们先从一个游戏热词开始说起，That's not my neighbor 这是2024年2月18日开始火起来的一个游戏，在3月底达到最高热度，之后降温，再到5月底又火了一次。 之后热度慢慢降低，直到现在，每天一万左右的搜索量。 用谷歌Ads关键词规划工具可以看...

### 204. No Title
- **Date:** 2025-10-09T18:40:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 时间到，今天的#哥飞小课堂 开始了。 我们先从这张图片开始，看懂了吗？ 这是在 Ahrefs 里查询 elevenlabs 的相关关键词。 还记得，昨天我给大家的提醒吗？ 说可以关注大需求相关的长尾小需求，也能赚到钱。 就有群有问，能不能举个例子。 那，今天的小课堂，算是其中一个例子。 这里的大需求...

### 205. No Title
- **Date:** 2025-10-09T18:16:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 以下是今日第二堂#哥飞小课堂 ，大家准备好，开始上课了。 刚才的问题是：为什么小排老师要选择 fast 3d 这个词，搜索量很小呀。 答案是，Fast3D 和 Fast 3D 是小排老师 Fast3d.io 这个网站的品牌词。作为品牌词来讲，有意义，有特点，没有别的网站用这个品牌词，不用搜索量太大，...

### 206. No Title
- **Date:** 2025-10-09T18:07:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 看一个 AI 生成信息图的网站 venngage.com ，月访问量 140 万，70%流量来自于自然搜索。 这个网站会被拿出来当案例讲，是因为我看到他在 Ahrefs 统计的 AI 模型提及度很高，而且是各个模型都高。 换句话说，这个产品的 GEO 做得不错。 一个典型的提问是这样的，美国人问 I...

### 207. No Title
- **Date:** 2025-10-09T17:43:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，中午来个#哥飞小课堂 ，跟大家分享一个真实案例，防止大家走入误区，防止大家踩坑。 今天的谷歌趋势，如果大家看七天内的全球 Generator关键词的相关搜索，会发现出现了好几个 nama 相关的关键词。 https://trends.google.com/trends/explore?dat...

### 208. No Title
- **Date:** 2025-10-09T17:35:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 刚刚问一位群友要到了一个游戏资讯站，给大家看看，到底长啥样。 大家可以跟着我一起打开谷歌搜索这个词 dreamy room ，看看.org 这个站排第几名，我这里是第三名。 大家还可以思考一下，为什么第 3的有 152K 访问量，但是第 5 的就只有9.4K 访问量。 感谢大家的截图，我看了下，or...

### 209. No Title
- **Date:** 2025-10-09T17:09:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家学习的热情很高，那就开个#哥飞小课堂 ，这次我们再聊聊 Information gain ，我翻译为信息增量，有些地方翻译为信息增益。 为什么讲这个话题呢？ 因为以下几个原因： 1、还有人想用偷懒的方法，用 AI 生成很多页面，来从谷歌获取流量； 2、还有人问，都说要优质网页才能拿到排名，那么到...

### 210. No Title
- **Date:** 2025-10-07T18:28:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 写在前面 本来只是在自己公众号里记录一些出海建站的踩坑过程,没想到被哥飞老师全群转发了,受宠若惊， 感谢哥飞老师转发!🙏 最近能拿到这个结果,核心就是系统性学完了哥飞老师的文章,然后老老实实照着做。事实证明:这套方法论完全可复制,关键看执行力。 从王者局回归新手村 从5月全职投入出海至今已近半年,...

### 211. No Title
- **Date:** 2025-10-02T22:48:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是孟健。 上周，我把自己的第一个出海站点部署上线。 算是把需求挖掘、开发、部署、获客到变现的闭环跑完了。 真的是：惊喜和意外齐飞，踩坑和成长并存。 这篇文章就把整个过程拆开复盘，希望能给正在筹备 AI 出海的你一些参考。 01 选词太随意，开局就挖了坑 当时我只打开 Google Tren...

### 212. No Title
- **Date:** 2025-10-02T16:14:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 前期上站是为了积累弹药库和上站体系，等真正来新词了，你准备好了，达到随时上站的状态。 10月1日 上午 10 点飞哥在群里说 Sora 2 邀请码接龙，于是去分析这个热词 通过追新词项目实战，积累快速上站经验，具体过程请听我慢慢讲来，含完整快速上站提示词。 1. 在 Trends 中找到新词： So...

### 213. No Title
- **Date:** 2025-09-25T14:13:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 前言 大家好，我是王马扎，从今年3月中旬开始动手做海外AI产品项目，到8月末突破1000刀。 这篇文章我将分享从0刀到0.01刀花了4个月，从0.01刀到1000刀花了15天的完整经历。 一、追新词，我花了4个月赚到第0.01刀 二、根据功能关键词，做品牌网站，赚到第1000刀 三、目前最大的卡点是...

### 214. No Title
- **Date:** 2025-09-24T09:43:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 半夜睡不着，写给自己的，顺便发出来鼓励鼓励像我一样的新手，随便写的没什么逻辑和章法。 一、预期管理 这里边分为主业的预期管理和副业的预期管理 主业 如果选择了8小时内求生存，那么升职加薪就不要羡慕别人了，60分万岁多一分浪费，上学时候没见自己内疚，上班了怎么还内疚上了。 另外很重要的一个需要培养的能...

### 215. No Title
- **Date:** 2025-09-23T08:48:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好我是小龙，今天我想分享一个关于我如何与“外链”这个东西死磕到底的故事。这不仅仅是一个关于SEO技巧的分享，更是一段关于热爱、探索和最终将兴趣变为产品的旅程。 缘起：从“飞哥”的新词比赛开始 故事要从23年底说起。那会儿， 飞哥连续做了几次新词SEO比赛，我都通过外链策略拿到了几次名次。这让我对...

### 216. No Title
- **Date:** 2025-09-13T19:07:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 最近听哥飞老师说，多找点词，才有选择的空间。为了找新词，发现关键词词根根本不够用，所以找到了这篇教程 通过查看 vercel.app 的子域名发现新需求。 运气比较好，刚实践就发现了这个词：rule34dle 直接查这个关键词 去查域名发现已经有好几个站长注册了，其中一个 org 后缀的站做的还很完...

### 217. No Title
- **Date:** 2025-09-12T02:50:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 最近在学飞哥的小游戏课程，看着各种月入万刀的网站，作为小白想抄都不知道从哪抄起，不知道别人的站好在哪里…… 但AI知道，总比我小白强👍。 让GPT、Claude、Gemini分别给了深度分析小游戏站的Prompt，直接复制输入你要分析的小游戏站的域名，拿去问AI就可以了。 从生成的分析报告来看，G...

### 218. No Title
- **Date:** 2025-09-09T03:18:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 从土木工程到AI出海，我放弃了五年拼搏来的副总经理职位，选择裸辞。几个月后，我在这个全新的领域赚到了第一笔美金。 这是一个普通人的跨界冒险，没有科班背景，只有一路的实战复盘和贵人相助。故事有点多，但每一步都算数。 大家好，我是井然。最近有不少朋友问我，是怎么在短短几个月内从土木工程跨进AI圈子、还最...

### 219. No Title
- **Date:** 2025-09-08T05:42:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 关于外链到底有什么作用，有些群友理解上有一些偏差。 大多数时候，我们群里说的外链，作用都是用来提升我们网站的权重，从而提升我们网站在我们要做的关键词搜索结果里的排名，从而得到更多的曝光和点击，得到更多 SEO 流量。 但的确，有一些外链，在刚发布时，是可以带来一些访问量的，甚至这些访问量里还有一小部...

### 220. No Title
- **Date:** 2025-09-07T00:03:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 众所周知，如果一个网页没有被谷歌收录，那么在这个网页上发布的外链是不会被谷歌爬取到的，但是每次都在谷歌里面site一下属实太麻烦，于是我就做了一个插件来帮我完成这件事，并且自动将当前url与搜索到的第一个进行匹配，如果匹配成功，那么就在搜索页面中间弹绿色弹窗，未收录就弹红色弹窗，然后自动关闭搜索页面...

### 221. No Title
- **Date:** 2025-09-02T18:04:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** Play Video AITDK SEO Extension - 流量/关键词/Whois/SEO分析器 推荐一款好用且免费的SEO插件，哥飞天天都在用 aitdk seo123  extension  [测试网站](https://pagespeed.web.dev/ )  [沉浸式翻译](htt...

### 222. No Title
- **Date:** 2025-09-02T07:24:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** Play Video 1、关键词除了tkd里面填充，页面h标签添加，除了这两部分还需要其他填充吗？ https://mp.weixin.qq.com/s/gRQkeat77A6fIRy5vXo73g 刘小排老师的 cc agents 插件 grow a garden //span[@class="s...

### 223. No Title
- **Date:** 2025-08-29T08:51:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是来自八群的我是一棵树，今年3月份刚接触web出海，4月份加入了哥飞的社群，“荒废”了两个月，6月才开始正式上站。第一次写分享，如有不妥，还望大家批评指正 （一）背景 网站类型：工具站 kd：30+ 搜索量：gpts7倍左右 域名购买时间：6月20 第一版上线时间：7月初 intitle结...

### 224. No Title
- **Date:** 2025-08-27T17:34:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** Play Video 为什么发外链,有什么用,怎么发,不能做什么, 1, 吸引蜘蛛,谷歌蜘蛛,爬虫 达成 我把谷歌蜘蛛吸引过来了,爬取我的网站, https://aistudio.google.com/prompts/new_chat 不懂就问 ai, ai.dev token 1M v2ex.co...

### 225. No Title
- **Date:** 2025-08-25T18:07:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** Play Video 问题收集于 https://new.web.cafe/topic/uop0al855y 后续更新的内容会根据这里提问,还有群里经常遇到的问题来进行录制视频.这个系列应该会更新 4 个教程左右,看情况反馈的情况来决定是不是在深入的录制具体的问题的解决方案, https://pag...

### 226. No Title
- **Date:** 2025-08-20T07:50:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 感谢哥飞邀请，有点流水账，但每一个字都是手敲的真实记录，也算是给自己毕业这六年的一个小总结。 （1） 初入职场 19年我从一所一本院校毕业后，告别父母和女朋友，拖着个旧箱子，来到北京开启了我的北漂之旅。 我第一家公司是VIPKid，做JAVA开发，作为一个非科班生，当时啥都不懂，慌得一批。但是我运气...

### 227. No Title
- **Date:** 2025-08-19T03:48:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 第一个站：从“瞎编”的需求到意外的收获 2024年3月，参与了生财航海的“出海第一站”，当时的教练是哥飞。他带我们学习如何找词、如何低成本建站。我当时为了省钱，只花15元买了一个 .xyz 域名。找词的时候也没认真分析，随便看了几个小时就选了一个差不多的关键词（image description），...

### 228. No Title
- **Date:** 2025-08-18T04:08:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 营销工具完全指南：从新手到专家 🛠️ 今天来聊聊那些能让我们事半功倍的营销工具。作为一个每天都在和这些工具打交道的人，我会分享一些真正实用的工具和使用技巧，让大家少走弯路。 备注：此视频还未录制 Google Search Console 进阶指南 GSC可能是最重要的免费工具了，来看看怎么用它挖...

### 229. No Title
- **Date:** 2025-08-18T04:05:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** Home 全 部  5月和6月新词新站比赛已经启动了，请大家踊跃参与  哥飞  2025-08-25 05:28  新词新站比赛  从大厂到老师，再到AI出海，一个普通人的6年总结  18  扬德洛夫斯基  2025-08-20 15:50  比赛栏目发布，新词新站比赛重启，快来参加2025年7月新...

### 230. No Title
- **Date:** 2025-08-18T04:04:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 备注：此视频还未录制 外链建设：竞品分析与实战指南 🔗 什么是外链？ 外链（反向链接）是指从其他网站指向你的网站的链接。它就像网络世界中的"推荐信"，对网站的SEO和品牌建设有着重要影响。 外链的重要性 提升搜索排名：搜索引擎将外链视为网站价值的重要信号 增加引荐流量：优质外链可带来相关性强的目标...

### 231. No Title
- **Date:** 2025-08-18T04:03:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 竞品分析：洞察对手，超越对手 🔍 竞品分析的重要性 在开始之前，我们需要理解为什么竞品分析如此重要： 了解市场竞争格局 发现未被满足的市场需求 找到差异化竞争优势 避免重复竞争对手的错误 预测行业发展趋势 Similarweb深度分析教程 🎯 备注：此视频还未录制 1. 基础设置与数据收集 账号...

### 232. No Title
- **Date:** 2025-08-18T04:01:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 营销指南概览 📋 本营销指南涵盖了从网站优化、内容营销到商业变现的完整解决方案，帮助你更好地开展数字营销工作。 备注：此视频还未录制 核心内容模块 1. SEO基础 🎯 掌握搜索引擎优化的基本原理 学习网站技术优化方法 了解内容SEO策略 建立完整的SEO工作流 Google Search Co...

### 233. No Title
- **Date:** 2025-08-18T03:47:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 💡 本教程参考了 Ahrefs 的 SEO 初学者指南 - 链接建设，链接是搜索引擎发现新页面并评估其”权威性“ 的重要方式。没有链接，很难在竞争激烈的关键词中获得排名。这是一个非常优秀的 SEO 学习资源。如果您想了解更多详细内容，强烈推荐访问他们的网站。 SEO链接建设指南 备注：此视频还未录...

### 234. No Title
- **Date:** 2025-08-18T03:47:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 💡 本教程参考了 Ahrefs 的 SEO 初学者指南 - 技术性 SEO，重要的是要确保没有技术上的障碍阻止 Google访问和了解您的网站。这是一个非常优秀的 SEO 学习资源。如果您想了解更多详细内容，强烈推荐访问他们的网站。 技术 SEO 技术 SEO 是确保网站能被搜索引擎正确抓取、索引...

### 235. No Title
- **Date:** 2025-08-18T03:42:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 💡 本教程参考了 Ahrefs 的 SEO 初学者指南 - SEO 的基础知识，了解如何优化网站以获得 SEO 成功，并掌握 SEO 的四大核心要素。这是一个非常优秀的 SEO 学习资源。如果您想了解更多详细内容，强烈推荐访问他们的网站。 SEO基础知识指南 备注：此视频还未录制 SEO基础概念 ...

### 236. No Title
- **Date:** 2025-08-18T03:29:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 💡 本教程参考了 Ahrefs 的 SEO 初学者指南 - 搜索引擎的工作原理，在开始学习 SEO 之前，您需要先了解搜索引擎的工作原理。这是一个非常优秀的 SEO 学习资源。如果您想了解更多详细内容，强烈推荐访问他们的网站。 搜索引擎工作原理指南 搜索引擎是用于查找和排名与用户搜索匹配的 Web...

### 237. No Title
- **Date:** 2025-08-18T03:26:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** SEO 优化完全指南 本指南将帮助您系统地学习和掌握 SEO（搜索引擎优化）的核心知识，从基础概念到实践技巧，循序渐进地提升您的 SEO 能力。 💡 本教程参考了 Ahrefs 的 SEO 初学者指南，这是一个非常优秀的 SEO 学习资源。如果您想了解更多详细内容，强烈推荐访问他们的网站。 学习路...

### 238. No Title
- **Date:** 2025-08-16T10:12:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** Hello，大家好，我是Leo，今年2月进的社群，前段时间（8月中旬）单个网站纯广告收入达到月入$1000。 这篇文章主要分享一下这个网站收入爬楼的过程以及过程中收获的的经验。 一、上站背景 上站目的：要么搞到钱、要么搞到技术。起步阶段要更多的搞到技术，成熟阶段要更多的搞到钱。 这个网站是我的第4个...

### 239. No Title
- **Date:** 2025-08-15T05:21:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 总是有朋友搞不清楚内链、外链、反链之间的关系，我写了一段说明，让 Claude帮我画了个图，然后自己再微调了一下画面。 说明文字： A 网站有一个指向到 B 网站的链接1。 A 网站还有一个指向到 A 网站内页的链接 2。 从 A 网站角度来说： 链接 1 是和链接 2 都是正向链接。 链接 1 是...

### 240. No Title
- **Date:** 2025-08-15T01:55:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 回答了不少群里朋友私聊问题，哥飞又发现一个不算少见的现象，就是看着竞争对手做得不好的地方去抄，心里想着既然他这样都能拿到流量，我的站也能拿到流量。 然后上线之后看GSC数据就发现，怎么没数据啊。 哥飞的回答是： 你也不看看别人的站做了十年八年了，积累了几千条反链，而你一个刚刚上线的新站，反链没几条，...

### 241. No Title
- **Date:** 2025-08-09T22:20:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 前几天 Google 发布 genie3，我第一时间抢到了 genie3.net 域名，现在已经拿到这个关键词的首页排名。我单方面宣布在 genie3 抢新词大战中获胜，哈哈。 分享一下核心的做法： 看到新词的机会，第一时间下手，拼获取「新词genie3」信息渠道和买域名的执行力。我买 genie3...

### 242. No Title
- **Date:** 2025-08-07T11:14:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** N-Walker - 熟悉 Semrush 平台的功能 - 1 - 竞争对手研究 项目 在 Semrush 中，项目是你要监控和分析的网站的集合单位。每个项目通常可以有： 你自己的网站 竞争对手的网站 你客户的网站 核心作用：项目让你能持续追踪一个网站的 SEO 表现，而不是每次都要重新输入域名查询...

### 243. No Title
- **Date:** 2025-08-06T01:37:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 哥飞 昨天有朋友问，为什么小排老师要选择 fast 3d 这个词，搜索量很小呀。 我想把这个问题抛给大家，考考大家，看看大家如何回答。 guoer 很好记忆，好传播 乐尽天 做品牌词 哥飞 是的，答案是这个，但是你还可以解释一下 乐尽天:做品牌词 greyson chen ling 是群友做的? g...

### 244. No Title
- **Date:** 2025-08-06T00:40:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 哥飞 预告一下，一会儿15点，#哥飞小课堂 开讲，最近有几个群里朋友都问过的问题，新站为什么给了一点曝光和点击之后，就突然就没有了。 如果还有朋友也有新站有类似问题，可以参照我刚发的截图，去GSC截图最近3个月的数据，发出来。 哥飞 哥飞 按照日期看数据，会更明显。 哥飞 Memory 还真有一个，...

### 245. No Title
- **Date:** 2025-08-04T00:43:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 刚被群友提醒，我之前拿来给大家演示的一个网站，忘记续费之后，被人抢住了，被拿去做域名停放赚钱了，而且配置的还是色情页面。 不续费的域名，过期后被人抢住，拿去做色情网站，这个好像没啥太好的解决办法。 理论上没续费了，这个域名就不是你的了，别人拿去做什么都行。 大家之前注册的域名，有些陆陆续续也都到期了...

### 246. No Title
- **Date:** 2025-08-03T23:42:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 给大家看一个网站，很有可能是群友的，但我不知道是谁的，今天看到了，就拿来当个案例给大家分享下。 今年1月9日注册的域名，1月11日上线了第一版，4月初上线了第二版，5月中旬上了第三版，之后微调了好几次文案。 流量的话，1月几乎没啥流量，2月有一点点流量，3月有35K，4月有65K，5月128K，6月...

### 247. No Title
- **Date:** 2025-08-03T19:40:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞。 社群里朋友找到一个关键词“pizza edition”，说优化难度低，让哥飞看看确认一下。 所以哥飞干脆开一个新栏目“哥飞看词”，时不时帮大家看看某个关键词是否可以做。 我们直接开始，先在谷歌趋势里拿“pizza edition”和“GPTs”比，会发现“pizza editio...

### 248. No Title
- **Date:** 2025-08-01T20:28:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 今天挖掘到的这个同行，搞了一堆的账号在个人介绍页面放这个链接，还是很骚气的，而且看起来权重都不低，不知道这种发外链的形式是否可行，感觉听骚气的，挺好的。 然后他自己做了一个聚合页，把自己所有的账号整理了一波，我找Ai提取出来了部分。 facebook.com linkedin.com x.com a...

### 249. No Title
- **Date:** 2025-07-31T09:42:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 一、使用关键词分析工具 🔍 站长工具（如 https://tool.chinaz.com/kwevaluate） 操作方法：打开这个网站，输入你想了解的目标关键词，比如 “timestamp”。 查看内容： 优化难度：这个数值能告诉你做这个关键词的优化难不难。如果≥90 分，就说明竞争特别激烈💥...

### 250. No Title
- **Date:** 2025-07-30T01:30:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 内容来源于@Gu https://new.web.cafe/topic/60wmnukjzg 一、先搞懂：找关键词前要判断什么？ 关键词就是用户在谷歌等搜索引擎里搜的词（比如“时间戳转换”“猫咪涂色页”），我们要找的是“容易做排名、能带来流量”的词。 1. 优先选容易做排名的词 核心逻辑：同样的关键...

### 251. No Title
- **Date:** 2025-07-24T03:20:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 哥飞 案例分析：月访问量从0到10万花了10个月，再涨到200万又花了11个月 https://new.web.cafe/tutorial/detail/7qzrnu5csg 昨天的公众号收费文章，可以免费看啦。 哥飞 哥飞 看下这个网站首页的流量变化你就发现，这个站其实坐了很久的冷板凳。 上线 2...

### 252. No Title
- **Date:** 2025-07-22T03:05:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 这个月初给自己定了目标：“获得稳定供应新词的能力”。 月中到处求贤问道，感觉终于有了一点小成，浓缩成下面这张表格，分享给大家。 把下面的表格复制到一个新文档，然后每天上班按部就班地填，就是一个找词的流程了。 词找词，词找站，站找词，都是可以联动的。明白了怎么联动，词就找不完了。 下面就演示了一个联动...

### 253. No Title
- **Date:** 2025-07-21T05:38:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 产品做完了，但是收款没搞定？对与初次接触 SaaS 收款的开发者来说，这确实是个艰巨的挑战。使用 Stripe 的门槛稍微有点高，使用 Creem 是个不错的替代方案。 本文分享 Creem 注册 + 审核验证 + 对接支付的完整流程。 注册 Creem 账户以及创建商店 注册 Creem 账户很简...

### 254. No Title
- **Date:** 2025-07-16T08:58:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 基于群友的帖子 https://new.web.cafe/tutorial/detail/9mmgk78zi4 加上我在收集外链中遇到的一些痛点，我做了一个外链管理站。主要用来比较方便的记录我自己收集了哪些外链。并且我自己的网站都已经在哪些外链站上添加了外链。（文末有git命令，可以安装部署到自己的...

### 255. No Title
- **Date:** 2025-07-12T23:33:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 各位哥飞的朋友们，大家好。 很荣幸今天有机会向各位分享我这半年多做出海AI的一些经历，如果分享的不够好，还请各位多多见谅。 今天分享的内容有以下几点： 长期坚持的源动力—我为什么选择做出海AI这件事？ 走出舒适区，逆转原有惯性—我是如何开始的？ 认知升级需要实战历练—我做过的那些产品； 破除既有路径...

### 256. No Title
- **Date:** 2025-07-10T02:52:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 0.2版本变更 感谢大家的反馈与宝贵意见！在大家的帮助下终于搞定了版本更新。 本次更新为用户提供了完整的 链接资源收集 → 标记使用状态 → 快速筛选应用 的闭环体验，让外链勘探与外链建设变得更加顺畅。 新增功能 在主页新增外链资源筛选与使用标注模块。可以按需筛选在链接勘探过程中标记过的资源。外链建...

### 257. No Title
- **Date:** 2025-07-09T18:48:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 入群后，就开始进行找词，学习了飞哥的找词经验后，我也尝试找词，但是很多时候，找到词后，不知道这个词能不能做，脑海很多概念都很模糊，为了清晰一点，我大概简短凝练了一些总结： 拿到新词后，我们执行以下SOP步骤来判断这个词值不值做。 一般总结下来是：新词更新容易拿排名，大流量词可以根据自身情况选择竞争，...

### 258. No Title
- **Date:** 2025-07-08T07:36:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 事情回到5月29号，那一天我闲来无事打开GSC后台看到页面索引掉半，突然整个人都傻了。于是开始在向哥飞和论坛上求助，得到了两个信息： 5月29号-6月1号有很多人跟我遇到了一样的情况 在和哥飞的讨论下，初步页面比较相似，重复读度高 于是我打开这次所影响的页面，发现都是一个目录结构下的多个页面被取消索...

### 259. No Title
- **Date:** 2025-06-26T00:02:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 产品推广 Play Video 外链建设 首先要让Cursor输出你的产品基本信息，名字链接介绍文案长文案短文案，营销图片文案等等； 另外要再新建一个Excel来整理外链； 然后还需要让cursor生成一些营销文案，比如这个项目需要做dribbble的文案，你也可以做twitter的文案； 最后每天...

### 260. No Title
- **Date:** 2025-06-25T23:55:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** SEO优化实践指南 本指南将为你提供一个完整的SEO优化工作流程，从关键词研究到最终的效果监测，每个步骤都配有详细的操作说明和工具使用指南。 Play Video SEO 优化的流程我一共分为6个步骤，分别是： 关键词研究与分析 页面内容优化 技术SEO优化 分析工具配置 外链建设策略 SEO效果监...

### 261. No Title
- **Date:** 2025-06-25T23:35:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 实战项目开发概览 Play Video 本章节将带领大家完整体验一个项目从构思到上线的全过程。我们将基于 aimaker-template 模板开发一个精美的天气图标产品网站。 (哥飞备注：该模板为 aimaker.dev 的付费模板，实战项目开发，代码部分仅作参考) 项目简介：Creamy Wea...

### 262. No Title
- **Date:** 2025-06-25T04:23:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 简单汇总了哥飞分享过的找词、需求挖掘思路和方法，主要方便学习和快速查找，格式粗糙、细节不全，仅供参考，最终以哥飞和社群大家分享的文章和视频为准。 一、判断思路 1、判断优先级： https://new.web.cafe/tutorial/detail/gz96vzpif7dW65iFcHDbTY 对...

### 263. No Title
- **Date:** 2025-06-25T04:04:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 作为哥飞社群的一枚新人，刚进来就被海量信息淹没了，花了几天时间把哥飞给的新人入门资料看了一遍。 因为信息分散在不同的帖子里面，为了方便以后快速查找某个模块的知识，就将信息做了汇总，将重要内容放到一起。今天共享出来，方便后面新来的同学查阅。 ps：这些汇总不包含基础的工具操作（这部分内容见养网站防老）...

### 264. No Title
- **Date:** 2025-06-25T01:13:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** BacklinkPilot - 外链建设辅助工具 这是个啥？ 简单说，就是我自己写的一个Chrome插件，用来收集外链资源，标注，自动生成文章评论等。 能干啥？ 📊 Ahrefs数据一键导出 在Ahrefs查外链的时候： 插件自动拦截API数据 点击绿色按钮直接导出到飞书表格 🎯 外链资源标注、...

### 265. No Title
- **Date:** 2025-06-23T17:58:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 前言：为什么要关心这个？ 作为国内的程序员，我们都有个共同的痛点：钱包不够厚，项目不能停。你是不是也遇到过这些情况： 个人项目想上线，但云服务器一个月好几百 流量突然暴涨，Vercel账单让你肉疼 想做个小项目练手，结果光基础设施就要不少钱 今天这篇文章，就是要教你怎么用 Cloudflare 配合...

### 266. No Title
- **Date:** 2025-06-22T04:17:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 外链建设是苦活累活，EgoLinks外链聚合平台可以光明正大留下自己的链接，并且把链接放到可以被搜索引擎收录的地方，加速收录和提供外链。有兴趣的朋友可以到EgoLinks平台上注册一个账号，然后把需要留下外链的网站聚合到一起，轻松获得一个外链。我在EgoLinks平台上精心创建并分享了一个极其宝贵的...

### 267. No Title
- **Date:** 2025-06-16T02:41:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞8群的新人薯片君，上个月的月中左右进来的哥飞社群。 作为新人，第一次在这里发帖，来介绍下自己关于上站的一些心路历程。 我这里没有什么炫酷的快速拿到结果，只有普普通通的一些入门经历和实践。希望拿到结果的大神们看到可以点拨一二，不胜感激！ 了解出海web 在进来哥飞社群之前几个月有了解到...

### 268. No Title
- **Date:** 2025-06-09T21:27:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 今天日常浏览热词的时候发现冒出来一个新词 nlweb https://trends.google.com/trends/explore?date=today%201-m&q=manus,mcp,openai,openrouter&geo=US&hl=en 大概2025-05-19号起来的新词，和GP...

### 269. No Title
- **Date:** 2025-06-08T19:55:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** Play Video 从Linguistics到Artificial Intelligence 关于我 - Kostja 3年AI从业经历 语言学背景 俄罗斯本科+德国研究生 22年8月-24年10月 | 入行 在一家Global的AI应用团队做增长，方向是图片/视频的生成和编辑 Cutout.pr...

### 270. No Title
- **Date:** 2025-06-08T19:53:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** Play Video 自我介绍 我是谁 群昵称Bing Ni 21年毕业，去了腾讯做后台开发 23年初离职 23年底加入飞哥社群，然后开始做出海工具站，练习时长1年半 实践篇 找需求 做网站 高流量 促转化 找需求 新手追新词 https://g31btelecl.feishu.cn/docx/Z7...

### 271. No Title
- **Date:** 2025-06-08T06:38:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 最近我发现，有些群友收入太高，已经不是普通群友可以追赶的了，对于大部分人其实没啥太大意义，可能也就是告诉大家，天花板有多高，但是天花板不是人人都能达到的。 反而多写写如何让大家赚到第1美元，如何实现每天稳定10美元，如何实现月入1000美元，这些入门教程，对大家更有帮助。 大家可以说一说目前的状态，...

### 272. No Title
- **Date:** 2025-06-07T00:53:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 最近看到很多朋友问怎么找外链、怎么发外链。 其实cafe网站论坛里已经有很多这类帖子，但是我看了下，大多数还是说的比较粗略。 很多刚开始做站的朋友，看了可能还是不好理解和操作。 很多操作细节对于已经熟悉的人来说，觉得很简单、甚至都不会注意到，但是对于刚开始起步的新手小白来说就会卡半天。 虽然我个人经...

### 273. No Title
- **Date:** 2025-06-04T03:48:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 前情概要+自我介绍 良辰美, 坐标深圳, 五年亚马逊电商 大学时期就一直想学代码编程, 可惜实战啃不动 23年跟着生财航海做了几期工具站志愿者, 尝试着开发谷歌插件和小网站, 奈何AI能力还不太行, 无一成功 24年看到哥飞公众号网站养老系列文章, 在生财航海群和哥飞会员群学到很多, AI能力大幅提...

### 274. No Title
- **Date:** 2025-05-29T04:08:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 搞了快两个月了，上了六七个站，写了一堆工具。 一顿操作猛如虎，一看流量五十五 😂 总结一下，希望和大家交朋友 1. 找词 手动：用google trends词根法，semrush/ahrefs/similar挖词，再用semrush筛，顺便扒外链里别人留的站 自动：游戏站sitemap对比工具👉...

### 275. No Title
- **Date:** 2025-05-27T06:02:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 上面的截图是这个网站上线后截止到目前的展示（曝光次数）数据，差不多半年时间。 下图是网站相关的搜索量最大的几个关键词的月均搜索量，所有加起来之后平均每天也就只有7百多。2月28日那天展示数有 770次，基本上算是到顶了。 当时发现排名下降后，就开始找原因，也发在群里讨论过（见下图）： 现在来看，流量...

### 276. No Title
- **Date:** 2025-05-26T22:14:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** Play Video 泽佳Clara998 这是一个关于出海创业的真实故事，从腾讯后台开发工程师的副业探索，到全职创业的挑战与突破，再到组建团队的实践经验。在这一年的历程中，我经历了从个人开发者到团队决策者的角色转变，积累了从选品到流量获取的完整方法论。 一、 个人背景与历程 职业背景 前腾讯后台开...

### 277. No Title
- **Date:** 2025-05-20T18:41:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 如果大家看了我上上周的公益直播视频，就知道，我反复说了一个点，谷歌为了保住自己搜索巨头地位，害怕失去最新鲜的网站供应，所以建立了最强的爬虫系统，不惜花费大量金钱也要去爬取尽可能全的网页。 谷歌最怕的是爬不全，而不是爬到了垃圾页面浪费资源。 只要爬下来了，谷歌就有很多办法来识别一个网页的质量，其中就包...

### 278. No Title
- **Date:** 2025-05-20T18:32:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 去年哥飞解读过 2024 年谷歌算法排名因素变化，里边提到了，细分领域专长占比14%。这篇文章，也出了2025版本，现在，我们先学习一下。 这是2024年的排名因素变化表格 从两张表格的对比可以看到： 持续发布吸引人的内容，占比从21%提升到了23%。也就是说，满足用户需求的重要性提升了。 Meta...

### 279. No Title
- **Date:** 2025-05-20T11:47:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 分享一下，先看数据，这个站在去年年底的时候大量上了ai生成的新页面，域名也是新的，导致大量被K，半年后收录只剩下59个页面，度过这几个月后，开始增长，目前收录了一半。 1.内容没有删没有改，几乎没有新增； 2.从开始减少收录的时候，大概是去年10月左右，开始上外链； 3.这些外链尽量为大型网站，多种...

### 280. No Title
- **Date:** 2025-05-18T17:33:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 经飞哥同意将自己公众号【辣条加辣】里觉得有价值的内容发布在这里，我是6群的辣条， 刚接触出海3个月，主要还是在做AI工具站，也赚到了第一美刀，算是刚刚入门，希望跟大家一块交流学习。 这个系列主要是自己想多看一些海外做的比较成功的AI产品，尝试拆解一下他们的冷启动，SEO，增长策略，当然还有产品层面，...

### 281. No Title
- **Date:** 2025-05-17T00:20:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 引言 很高兴可以上榜, 十分感谢哥飞, 秘诀都在哥飞老师公众号, 日常的分享当中, 希望大家可以坚持全部刷一遍, 并且不断执行. 需求挖掘 两种模式人找货, 货找人 谷歌的搜索词可以被看作用户主动寻找“货”的行为。可以基于用户的搜索行为匹配合适的产品（人找货）；也可以是我们已有产品资源，再通过关键词...

### 282. No Title
- **Date:** 2025-05-16T23:42:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 引言 大家好，我是蛋壳，很荣幸能够获得新词新站比赛的第二名，虽然有运气存在，但是也有能够看得见摸得着的规律。我的网站是https://Ghibliai.ai 欢迎大家去看 发现关键词 这是一个平静的晚上，我习惯性的打开google trends 搜索chatgpt, ai等词根 发现了一个流量极大的...

### 283. No Title
- **Date:** 2025-05-15T02:56:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 一个很简单的npm包，一周8千万的下载次数 https://www.npmjs.com/package/mime-types 现在AI生成一个NPM，几乎没成本了，可以去找一些有下载量，但是好久没更新的开源仓库，你写一个新版本，提交上去，就能够得到一些外链了。 npmjs.com DR 92 同理，...

### 284. No Title
- **Date:** 2025-05-10T19:42:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 各位群友周末好呀，我是一恒。 最近crazy cattle 3d这个词爆火，很多人都在做，竞争异常激烈，甚至可以说是惨不忍睹。 从最近的数据看，胜出的主要是crazycattle3d.com, crazycattle3d.io, crazy-cattle-3d.com这几个，流量最高的crazyca...

### 285. No Title
- **Date:** 2025-05-08T05:07:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 做工具站，英语过关的话强烈建议维护个discord，体验下来好处挺多。 我最近的几个站都用一套标准流程上了 discord 社群，留存了几十到几百个老外不等，评估下来觉得对早期的开发迭代很有用，所以整理成文分享在这里。 好处省流版： 降低投诉率，他有问题会直接来找你 可以直接跟他们收集反馈 用户肯定...

### 286. No Title
- **Date:** 2025-04-22T22:38:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** SEO 外链建设策略指南 根据睡飞大佬的SEO外链建设实战手册，我总结了一个文档，供大家参考 一、工具准备与竞品分析 核心工具 Ahrefs/SEMrush：反向链接分析 Grammarly：内容润色 ChatGPT：评论内容生成 竞品反向链接抓取 输入竞品网站，选择「活跃外链」筛选 导出数据并分类...

### 287. No Title
- **Date:** 2025-04-21T23:51:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 给大家列了一下学习指南 新手入门，先把这个 Ahrefs 的公开课程过一遍 https://ahrefs.com/zh/seo 。 不需要读懂，大概读一遍，了解一下SEO的概念就行。 然后看这个进阶教程，这个阶段也不需要仔细研究，就是看，就是了解。 https://new.web.cafe/tuto...

### 288. No Title
- **Date:** 2025-04-20T02:49:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 摘要 本文为新手小白提供了一份外链建设的实用指南，涵盖如何获取外链资源、筛选高质量资源、通过评论发布外链的技巧，以及检查和记录的方法。结合个人经验，旨在帮助新手快速上手并高效完成外链建设。本文适合自己动手的新手，手握大量资源的大佬或外包老板可直接略过。 引言 刚才在一个论坛上刷评论时，看到所有的评论...

### 289. No Title
- **Date:** 2025-04-11T00:04:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 使用谷歌高级搜索功能。 我在打工，给公司网站做外链时突然想到的一个方法。 我问 GPT：能不能用 谷歌高级搜索 检索出 "submit company", "submit your company"之类的结果 GPT 回答：可以的！你完全可以用 Google 高级搜索语法 来批量挖掘出能提交公司信息...

### 290. No Title
- **Date:** 2025-04-09T19:48:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 朋友们，关于挖掘需求，哥飞又有了一个新思路。 之前哥飞教了大家如何根据竞品网站的外链，找到可以发博客评论外链的网站 https://new.web.cafe/experience/ao30ki8tzk 。 刚在想，所有会去发外链的网站，其实都是有利可图的，不然他就不会去搞外链。 如果我们把评论列表里...

### 291. No Title
- **Date:** 2025-03-31T23:55:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是圈圈，在使用了群友 https://bestlinks.530.news/ 获取最佳外链后。 我做了一个自动化，批量导入对标网站，获取众多外链。 由于我做的基本都是游戏站，所以大多数是博客评论。 博客评论大多数都要填这些信息： 用户名 邮箱 网站 评论 为了防止博主不放出我们的评论，所以...

### 292. No Title
- **Date:** 2025-03-23T18:53:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 故事起因 起因是群友在讨论如何获取外链，然后哥飞分享了一段聊天记录：群友@安于不安 提到ahrefs外链检查工具返回的20条记录是 best links，而这里所说的 best links 是ahrefs 平台采集到该域名的最佳外链。然后就有群友开始讨论是否可以逆向一下网页然后拿到数据，这一下提起了...

### 293. No Title
- **Date:** 2025-03-23T04:15:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是安于不安，分享下我平时是怎么收集外链的。 核心方法还是飞哥和群友们经常说的抄同行，只不过是在日常找词的同时顺便收集外链。 原来的流程可能是：找词 - 上站 - 找同行 - 收集外链 - 发外链 现在是：找词(+收集外链) - 上站 - 筛选高质量外链 - 发外链 外链查询工具也是经常提到...

### 294. No Title
- **Date:** 2025-03-19T23:46:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 很多小伙伴做完了自己的工具站，都有找工具导航站来提交自己网站的需求，我这里分享一个方法给大家 我是阿威，我在六群，希望能跟大家多多交流 开门见山，就一句Google搜索语法 inurl:"submit" intext:"submit" AND "tool" intitle:"submit" AND ...

### 295. No Title
- **Date:** 2025-03-12T06:48:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** === 很多朋友来问我说为什么我总能找到这些干货。这里偷偷告诉你们， 我是看了 外链SOP：如何找能够发外链网站 哥飞小课堂24.10.25 外链小课堂 新网站上线，做扎实站内内容，同时做好外链。 分享一个全新的挖掘需求的小思路 谷歌趋势用法以及如何找到发外链的地方 以上哥飞之前发的外链的帖子， 寻...

### 296. No Title
- **Date:** 2025-03-05T23:24:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 关于需求挖掘： 上个月做了10个站，都是新词新站，但真正起来的只有4个站，但基本上起来没多久因为词的热度下降了，导致网站流量也跟着跌了，我觉得我现在对新词是有一套SOP的，这里就直接名牌分享给大家 我刚才看了一眼docx文档，我到目前为止积累的词根（包含但不限于工具、游戏）已经超过100个了，其中有...

### 297. No Title
- **Date:** 2025-03-03T22:15:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 自我介绍 hey 社群的朋友们你们好。我是小李。2月刚入哥飞社群。 很高兴能把自己暴死的网站(也是入社群后第一个网站)当做反面案例教材给大家剖析。 背景 站点的定位是工具。 2.20左右定好关键词， 买好域名，和哥飞沟通思路以后，就上站了。 上站以后迅速收录，一开始的位置是26名。 第二天开始添加种...

### 298. No Title
- **Date:** 2025-02-27T01:11:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 一个PHP做的个人网站进化史，作者的介绍页面，写于2015年3月，刚好就是10年前。 而这个网站 [fantasynamegenerators.com]((https://fantasynamegenerators.com/) 是2012年上线的，现在月访问量 370万。 这里有一个dofollow...

### 299. No Title
- **Date:** 2025-02-19T19:42:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 有朋友不了解博客评论外链怎么回事，我找了一个WP博客评论区截图给大家看看。 严格来说，用博客评论来搞外链，这是在给互联网创造垃圾信息。 但是，目前实践表明，这种方式获取的外链依然还有效，所以我们明知道不对，也会去做。 那么问题就变成了，怎么让自己的评论不那么垃圾了。 举例，你可以通过谷歌site语法...

### 300. No Title
- **Date:** 2025-02-18T16:53:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 今天的#哥飞小课堂 带大家看两种不同的网站类型，我会拿了两个网站来举例。 类型一，参考网站 anythingtranslate.com ，首页不带来流量或者只带来很少流量，网站的大部分流量由很多个内页带来。 注意，这里首页不带来流量的可能原因是首页瞄准的关键词竞争度太高，暂时没有拿到排名。 并不是说...

### 301. No Title
- **Date:** 2025-02-18T02:17:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 有些关键词，谷歌直接给出能够满足用户需求的产品，这时候这些关键词，即使搜索量再大，我们都需要去避开。 pacman 这个词月搜索量400万+，但是这个排第一的网站月访问量18万。 投入了800个外链资源，但只拿到了18万的月访问量，这就划不来。...

### 302. No Title
- **Date:** 2025-02-16T17:46:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 如何在GA中看流量来源渠道。 关于不是有了外链，就一定能够拿到更靠前的排名，一个很好的例子。 https://blockblastsolver.com/ 注册于2024年9月1日，blockblastsolver.org 注册于2024年10月7日。 前者只有43个外链域名，DR20，后者有145个...

### 303. No Title
- **Date:** 2025-02-14T00:27:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 有幸拿到新词新站第一名。要分享经验，似乎又没什么好分享。 如果这篇文章是别人写的，我可能前三段看完都不会继续看下去了，因为都是老生常谈的那些话： 一是相信，二是"去做"，三是运气，四是永无止境地迭代，优化"去做"，更精准地"等运气"。 如果已经理解了上面4句话，下面也没什么必要读下去了。 只是一些我...

### 304. No Title
- **Date:** 2025-02-10T03:36:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 给大家分享个文档，值得学习 《SaaS工作手册 2.0》暨有赞十二年的经验教训总结 https://qima.feishu.cn/wiki/DYSZwoKobibViRk4VP7cnuNLnZU geometry dash 这个词，群里很多人估计都找到过，我刚看了下，目前排前面的，居然是两个2024...

### 305. No Title
- **Date:** 2025-02-10T03:19:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 今天的#哥飞小课堂 ，我们聊聊如何基于数据驱动，做好上站之后的一些宣传推广工作。 很多朋友，刚开始做的几个网站，做的事情兴冲冲，做完就发现，怎么没流量呀？ 我今天就来告诉大家怎么排查问题，怎么基于数据驱动做事。 说是上站之后，是因为我默认大家做的网站，已经是做好了关键词研究工作，挖掘出来了有搜索量的...

### 306. No Title
- **Date:** 2025-02-04T22:58:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家还记得除夕那天我上线的两个网站吗？ 因为我的一个骚操作，A网站的排名没了，于是B网站才有了一点机会，当然更大的机会，被群里朋友的网站接住了，所以他的流量肯定比我的网站B更大，有可能是我的两三倍。 想要知道是什么操作吗？ 新年过后第一次#哥飞小课堂 一会儿就开课，来先拍拍我，看看多少人在线。 春节...

### 307. No Title
- **Date:** 2025-01-16T23:08:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞。 前天我们在《花半天开发的网站上线一周，今日3000人访问，他是怎么做到的？》文章中介绍了 GeminiProChat.com 通过开源模式免费获取了大量宣传资源和外部链接。 今天，他的网站流量又创新高，现在已经有4700了，还剩2小时，到今天结束应该能到5000。 网站地址：ht...

### 308. No Title
- **Date:** 2025-01-16T22:38:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞。 周日上线的网站 Stable-Video-Diffusion.com 到今天周二晚上21点多，已经有2000个用户访问了。 这是一个上传图片，免费生成视频的小工具网页。 域名其实11月22号就注册了，不过一直在忙别的，就没去建站。 直到11月25日，也就是上周六晚上九点半，社群里...

### 309. No Title
- **Date:** 2025-01-16T02:49:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 网站做好之后，我们需要让搜索引擎尽快收录我们的网站，之前哥飞讲了一个办法： 答案是去V2EX发帖介绍自己产品，然后留下网站链接。这个方法10年前就有用，现在更有用了，因为V站在谷歌的权重更高了。 我是哥飞，公众号：哥飞 新上线的网站，如何快速让谷歌收录？做网站为什么要生成几十万个页面？ 这个方法其实...

### 310. No Title
- **Date:** 2025-01-16T01:36:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞。 昨天到广州与几个朋友小聚，晚上有事没写推文，今天一觉醒来已经八点多了，所以今天的推文迟到了，跟大家说声抱歉。 前几天哥飞文章《从一本书名到发现一批大流量工具站和内容站全流程揭秘》里回答了大家一个问题，搜索量10K左右的小词能不能做。 在Semrush中，搜索量是月度数据，你想想一...

### 311. No Title
- **Date:** 2025-01-15T23:00:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 给大家看个关键词，因为已经有群里朋友做了相关网站，并且拿到了靠前的位置，所以不发具体的关键词出来。 我们只看趋势，红色是GPTs，蓝色是这个词。 这个词最早在11月9日出现，当天热度是GPTs的20%左右。 第二天11月10日，.com 域名就被群友注册走了，目前拿到谷歌搜索前几的也是这个域名。 1...

### 312. No Title
- **Date:** 2025-01-15T19:57:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** https://mp.weixin.qq.com/s/WwChJ0C0LG5dar2Nk0RMSg 写了个开头，剩下的我后面找个时间，在哥飞小课堂讲解。 这个站长还做了另一个工具网站 https://eon.jp/ ，不过访问量不大。 我分享的，都是经过了实际检验有效的 我每次修改了哪些文案、什么时...

### 313. No Title
- **Date:** 2025-01-15T19:04:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 刚看到个游戏站，2005年注册的域名，现在月访问量230万。 https://armorgames.com/ 最开始看到域名时没想起来，后来看到游戏开头动画终于想起来了，以前我们玩过的很多在线游戏，都有这个动画开头，是个老厂牌了。 以下介绍来自于Claude： Armor Games(最初名为Gam...

### 314. No Title
- **Date:** 2025-01-15T19:00:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 今天的#哥飞小课堂，给大家分享一个全新的挖掘需求的小思路。 方法很简单，几句话可以说完，听懂的掌声。 既然很多搞外链的都知道某些网站的文章评论区可以留链接，于是他们都去评论发自己最新网站。 那么我们如过收集足够多的这样的文章，定期去爬最新的评论区，我们就可以得到最新上线的一些网站。 这些网站既然急需...

### 315. No Title
- **Date:** 2025-01-15T18:59:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 时间到，今天的#哥飞小课堂 跟大家聊聊怎么发外链。 发外链，很有用的一个策略就是抄作业。 其实很多地方都可以抄作业，挖需求可以抄作业，搞外链更是可以抄作业。 之前哥飞就在群里说法，找到能够发外链的地方的最好办法就是去找同行的网站抄作业，看看他们在哪些地方发了外链。 我们也可以去这些地方发。 具体怎么...

### 316. No Title
- **Date:** 2025-01-15T18:39:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 今天的#哥飞小课堂 跟大家总结一下最近做游戏站的一些经验。18:30 开始。 开始之前，大家可以回顾一下之前群里聊过的游戏相关的讨论。 Wordle 填字游戏在海外火热，原版游戏被 New York Times 收购 https://web.cafe/messages/topic/987 《泰晤士报...

### 317. No Title
- **Date:** 2025-01-15T18:24:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 单程车票： 请教大家一个问题，我按照bing上的教程，打开cloudflare的Crawler Hints，，但是我看每天都是推icon，robots之类的，并未推实际上线的网页，是哪里操作有问题吗？ domenic：看了下，我的也是，提交的都是些没用的东西 单程车票：对，我每天也都是推这些 dom...

### 318. No Title
- **Date:** 2025-01-15T18:12:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 今天的#哥飞小课堂 ，聊聊如何通过产品设计和发起运营活动，让用户自发传播我们产品，进而获取外链。 用户其实很愿意传播他自己发布在平台里的内容，尤其是如果这个内容还能够给他直接或者间接的带来一点利益的话，用户会更愿意传播。 这里的利益可以是真实的，也可以是虚拟的。 真实的可以是礼物奖品、金钱奖励等等。...

### 319. No Title
- **Date:** 2025-01-15T18:06:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 久违的#哥飞小课堂 开课了，今晚借着哥飞某个网站数据，跟大家聊聊GSC后台的排名和点击率。这里的排名是综合所有关键词的平均排名，点击率也是所有关键词的综合点击率。 如果有一天你突然发现，怎么连续几天排名下降了，点击率下降了。 这时候不用惊慌，一定要点开GSC的比较功能，之后用筛选功能，不断添加过滤条...

### 320. No Title
- **Date:** 2025-01-15T17:35:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 刚才有朋友问 sitelinks 和 mini sitelinks ，今天的#哥飞小课堂 就给大家讲一下。 上面这张图片里，搜索结果下方出现的 explore 等链接，就是 sitelinks 。 Sitelinks 有可能单列，也有可能双列。 Sitelinks 通常出现在你搜索某个网站的品牌词时...

### 321. No Title
- **Date:** 2025-01-15T03:17:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 预告一下，16点，今天的哥飞小课堂教大家怎么不写代码做在线网页游戏，然后做落地页搞流量，赚广告费。 先给大家玩一下，我刚才花了几分钟部署好的一个小游戏，一个超级简单的射击小游戏，不过这个游戏不是我开发的，但却是我用工具生成的游戏代码，使得可以部署到自己服务器，自己域名下。 https://seo.b...

### 322. No Title
- **Date:** 2025-01-15T03:05:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家下午好，今天的#哥飞小课堂 拿某位群里朋友的一个比较典型的，SEO没做好的网站当作案例，跟大家分析一下，有哪些点没做好，以及要怎么改进。 这个网站域名是 c2story.com ，上线于6月份，到现在也三个月时间了。 其实只看界面的话，这个网站UI还是挺漂亮的。 但是很多SEO细节，的确是没做好...

### 323. No Title
- **Date:** 2025-01-15T02:28:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 看到个从老外推文学到的被动获取外链的方法。 今天的#哥飞小课堂，哥飞根据自己的经验补充完善如下。 其实跟我们做导航站思路是一致的。 在你的网站里写一些最好的XXX相关主题文章，里边列出N个XXX类产品，并且给出链接。其中，还可以把你自己的产品也放到列表里去。 文章底部留一个邮箱，让别人可以联系到你。...

### 324. No Title
- **Date:** 2025-01-15T02:00:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 今天的#哥飞小课堂 有点早，跟大家聊聊一些图片类关键词的数据怎么看，怎么判断能不能做，要不要做。 我们拿 sky background 这个关键词来说，PC端使用谷歌搜索，会发现谷歌能够识别到这是图片搜索需求，所以直接出现了“Images”模块，直接给你显示了一些图片。 这时候，大部分人可能直接就会...

### 325. No Title
- **Date:** 2025-01-15T01:47:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 好了，今天的#哥飞小课堂 就要开始了，老规矩，我在分享期间，大家先不要发言，有感悟了想鼓掌，可以拍一拍我。 先给大家讲讲故事，去年九月到今年三月，我受邀到生财有术社群当了几次出海航海教练。 今天的案例网站 describepicture.org 就是去年12月航海（实际航海开始时间是元旦后）时，其中...

### 326. No Title
- **Date:** 2025-01-15T00:18:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 今天的＃哥飞小课堂 聊聊一些大家目前用得上的广告指标。 广告曝光 你的广告被展示出来了，展示一次算一个曝光。 广告点击 有人看到了你的广告，点击了广告，打开了你的网页，就是一次广告点击。 我们设置广告时，需要设置我们愿意出的每次点击最高单价。 一般实际广告点击单价费用都不会超过我们设置的最高单价，但...

### 327. No Title
- **Date:** 2025-01-15T00:00:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 今天的#哥飞小课堂 ，我们来看一个搜索量还挺大的词 ai face swap 和 face swap ai ，虽然看起来是两个词，并且搜索量实际是不一样的，但是因为意思相同，需求相同，并且谷歌趋势也把这两个词的热度值看成一样，所以我们也当作同一个词。 如果单纯看KD的话，会觉得有一定的难度，我们通常...

### 328. No Title
- **Date:** 2025-01-14T23:06:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 15点时间到，开始今天的#哥飞小课堂 ，老规矩，在我分享期间，大家先不发言，等分享结束统一提问答疑。 今天的主题是，再聊内链和内页，以及如何做好一个内容型工具站。 大家听过哥飞无数次在群里说，有些关键词，别人靠内页，就能够拿到排名，如果我们做一个网站专门做这个关键词，举全站之力去优化这个关键词，那么...

### 329. No Title
- **Date:** 2025-01-14T22:42:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 今日份的#哥飞小课堂 就要开始了。 老规矩，在我分享期间，大家先不要提问，听到有触动的拍一拍我即可。 上来先给大家看词，并且哥飞整理了前三名网站信息。 pokerogue.net 2024-02-25 注册，210个反链网站 pokerogue.io 2024-04-17 注册，270个反链网站 p...

### 330. No Title
- **Date:** 2025-01-14T19:54:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 今天的#哥飞小课堂 补充昨天的谷歌趋势用法。 看上面截图，不知道大家发现没有，居然可以不输入关键词就能够找到热门内容。 谷歌趋势有以下筛选条件： 国家地区； 时间区间； 类目； 谷歌产品形态（搜索、图片、视频、购物）。 假如我们持续跟踪全球不同国家的每天每一个类目的热门搜索，是不是就能够建立一个关键...

### 331. No Title
- **Date:** 2025-01-14T18:59:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 今晚的#哥飞小课堂 ，我给没有参加北京场线下聚会的朋友们讲讲Henry的分享内容。 先从一张图说起。 怎么理解这张图呢？ 网站首页瞄准主关键词，但是新网站上线，没什么权重，谷歌不会给排名和曝光。 这时候，可以做的是，做扎实站内内容，同时做好外链。 站内内容可以从主关键词开始下探，找出所有二级词，但是...

### 332. No Title
- **Date:** 2025-01-14T18:40:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 今晚＃哥飞小课堂 发一个小技巧，不知道大家有没有对比过，为什么 woy.ai 在 ahrefs 的 DR 这么高？ 看图你会发现，woy.ai 只有56个外链网站，就有53的DR，而 toolify.ai 和 hix.ai 有几千个外链网站，也才六十多的 DR ？ 给一个提示，看看上面这张图片，对比...

### 333. No Title
- **Date:** 2025-01-14T00:48:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 本文原作者@ForWink ，什么值得读站长，哥飞申请转载过来分享给大家，本文赞赏后续全部转交给原作者，原文请见文章底部左下角“阅读原文”。 产品开发的完成只是一个开始，推广才能决定产品能走到何种高度。 以下介绍的都是免费的推广渠道，这些渠道能帮助独立产品获得免费的初始流量。 希望这份文档能够助力国...

### 334. No Title
- **Date:** 2025-01-14T00:22:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 先放上面这张图镇楼，月访问量4880万，年收入200万到500万美元，这是工具站的顶级Top存在了。 大家小板凳坐好，我开始聊下，如果要做一个时间戳工具，会怎么做。因为我们是竞争者，所以用全力，所以每个语言单独做一个站。不太理解的可以先看下本公众号之前的文章。 这里以英文为例，其它语言以此类推，同理...

### 335. No Title
- **Date:** 2025-01-13T23:43:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 今天哥飞建的付费社群“哥飞的朋友们”群友@赖嘉伟Gray 给大家报喜了，他新上线的网站，9天时间，已经拿到11030个独立访客了。 这源于 Threads 上线那天，我在群里的一个提醒： 我想的是，因为（Threads）是 instagram 出的，所以我们可以赌一把，赌他能做起来。那么就可以去分析...

### 336. No Title
- **Date:** 2025-01-13T23:18:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 7月8日，哥飞受邀参加了刀姐组织的广州线下聚会，这是我在聚会上的分享，现在根据录音整理成文字版本分享给大家。 请大家先记住一个关键概念：流量思维。 我们创建网站的目的是从搜索引擎吸引流量，制作视频号或抖音账号是为了从推荐系统获取流量。你在 Instagram 上发帖也是为了从各种推荐算法和转发中吸引...

### 337. No Title
- **Date:** 2025-01-13T23:08:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 有人问哥飞，都2023年了，还有必要做个网站吗？ 为什么不去做App？ 为什么不去做小程序？ 为什么不去短视频平台做账号？ 哥飞今天就来聊聊这个话题。先说结论，2023年了，你很有必要有一个自己的网站。 如果从获取流量的角度，短视频平台做账号跟十几年前站长做网站差不多，都是从平台获取流量。 但是，短...

### 338. No Title
- **Date:** 2025-01-13T19:19:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** #哥飞小课堂 开课了 我最近有种感觉，其实谷歌的最小排序粒度是网页，而不是网站。 我们通常说一个网站的权重高，其实也可以说是他的首页权重高。 大多数时候，首页就是根目录，但有些网站是 /home 或者 /index 或者 /welcome 等带路径的。 是根目录还好理解，为什么带路径的首页，在排序时...

### 339. No Title
- **Date:** 2025-01-13T18:42:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 周六凌晨做的网站开始有曝光了，主页做核心关键词，内页做细分关键词，内页也可以拿到曝光。 蒲公英：太厉害了，我也是周六上的，目前就有点收录，0曝光 哥飞：一个小经验，同一个页面，不要同时有大词和小词。 或者说，不要去盲目追大词，不然可能会因为拿到了大词的曝光，但是排名低点击率低，就使得整体点击率降低，...

### 340. No Title
- **Date:** 2025-01-13T01:59:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** #哥飞小课堂 开课了 刚树哥群里有人发了这个网站 https://coopwb.in/ ，7月份注册的域名， Similarweb 显示上个月访问量880万，Semrush 显示自然搜索流量1130万。 不过目前已经被谷歌K站了，Bing 的收录还在。 给大家留个周末作业，分析一下这个网站靠什么短时...

### 341. No Title
- **Date:** 2025-01-12T23:58:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 哥飞小课堂开课了，今天说说如何不靠碰运气找到值得做的词。 先说理论知识，高流量网站通常都是做得比较久，权重比较高的。 所以很多关键词，这些网站有时候只是一个内页，就可以有不错的排名。 那么我们就利用这个特点，通过高流量网站去找词。 方法很简单： 1、打开 similarweb 的网站排行榜 http...

### 342. No Title
- **Date:** 2025-01-12T19:24:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 关于反链，今天哥飞小课堂再讲一下。 先说反链是什么 反链，就是反向链接，backlink。 有反链就一定有正链。 从我是站长的角度，正向链接指的是我的网站内放置的，别的网站的链接。 那么反链就好理解了，指的是存在于别的网站的，指向到我的网站的链接。 我们通常查反链，一般就是用于看，有哪些网站放置了我...

### 343. No Title
- **Date:** 2025-01-10T17:16:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 题主是个刚做站的新人，主要做的是游戏内容站，本帖主要基于个人上站后观察到的关于内容质量的推测 网页内容质量对网页收录的影响 谷歌已抓取 - 尚未编入索引 如果网页的内容质量不高，在将sitemap提交到谷歌后会出现谷歌只收录了个位数、十位数的网页，而其它页面一直不收录的情况。 无法编入索引的猜测 个...

### 344. No Title
- **Date:** 2025-01-04T05:27:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 很多时候，词不用刻意的去找，只要你掌握基础方法了，那么在每天的上网过程中，就能找到一些关键词。 今晚，哥飞本来是想分享某个网站，结果后来发现了一个新词。所以在这个帖子记录一下完整过程，后面大家也可以跟着这个流程走，多多练习，你也能学会找词。 这个站 elgoog.im，致力于把历年谷歌的一些彩蛋给复...

### 345. No Title
- **Date:** 2024-12-27T03:33:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 无特别领域的广撒网找词 SOP 卡诺: 进群也一年了，除了一开始折腾了一波 gpts(还上了个榜呢)，之后由于种种原因，到现在再没出手上站，之前买的域名都过期几个了。。。 好在最近终于工作和家庭有点空隙，痛定思痛，决定静下心来好好搞一波 昨晚开始找词的时候发现有些卡点，于是今天先一顿搜索群聊天记录，...

### 346. No Title
- **Date:** 2024-12-19T05:25:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 近期发布了一个网站，前几天曝光势头良好，第4天曝光突然暴跌，连续一周几乎跌为0。怀疑被谷歌惩罚了，一直百思不得，直到今天在外链中发现多了不少奇怪的外链，才意识到受到垃圾外链攻击了。 通过Ahrefs的外链工具，发现是垃圾外链快速增加的时间正好是流量暴跌的时间，合理怀疑我的网站因为垃圾外链比例极高，导...

### 347. No Title
- **Date:** 2024-12-15T03:44:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 这篇文章是针对还没入门的游戏小白来说的，大神可以直接略过。 最近几个月的榜单都被小游戏占据了，大家都在关注小游戏这个赛道。对于新手小白来说，如何找出最新的爆款小游戏是项基础的技能。即使找到了一些新的小游戏，还需要评估它们是否值得投入去做，不可能每个都去做。我们可以从游戏类型、市场需求、竞争程度等多个...

### 348. No Title
- **Date:** 2024-12-09T22:58:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 周末线下去参观了飞哥的办公室，与小伙伴们聊了一下关于网站的时候。 在聊的过程中发现了一个痛点，就是网站太多了，有时候不知道哪个域名做了内容，哪个域名没有上线，管理起来比较麻烦。 我这里分享利用免费ahrefs账号，可以绑定上百上千个网站。 大家都知道ahrefs可以检查域名的外链、关键词等，但是检查...

### 349. No Title
- **Date:** 2024-12-04T19:56:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 在计算KDROI时，公式中需要一个required backlink参数，这个数值与SEO关键词的Keyword Difficulty（KD）相关，在Ahrefs 的Keyword Difficulty Checker中给出了一个简易的对照表。 那么，我们能不能根据这个对照表，反推出表示 KD 与外...

### 350. No Title
- **Date:** 2024-12-03T20:30:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 新词建站过程记录。基本过程如下： 1、新词查找(0) 思路是先确定基础词，这个基础词的来源，可以根据哥飞的微信公众号文章中的来查找，找到后，就可以在Google Trends中长期关注，这个没什么取巧的方法，需要长期慢慢来找，一下子就找到新词的概率很低，找到了也要交叉去验证准确性，我现在基本使用gp...

### 351. No Title
- **Date:** 2024-11-25T17:11:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 一、成果展示 大家好，我做的是一个关于 Morse Code的网站 先给大家看下我的成果，大概半年多的时间，流量从0慢慢增长到现在每天4K多UV，8-9K PV 这个成果虽然比不上群里的各位大佬，但是对我来说却是真正做到了从0到1，证实了这是一条可以长期持续投入的道路 当然，我其实做了1、20个网站...

### 352. No Title
- **Date:** 2024-11-12T19:07:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 群里有朋友问：上线两天，曝光次数低咋办？ 哥飞的回答：先检查页面内容长度够不够，关键词密度够不够，如果不够就改内容。然后再看排名是否很靠后，如果是，就加外链。 又有朋友问：页面内容长度大概什么要求的？ 哥飞的回答：我一般要求一个页面单词数量不小于600，然后800以上更好...

### 353. No Title
- **Date:** 2024-11-11T17:41:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 刚才有位群里朋友找我帮他看新上线的网站，我一看，就发现两个典型问题： 1、页面单词数量不够，整个页面只有71个单词； 2、核心关键词密度不够，无关单词出现次数太多。 这两个问题，都会导致谷歌无法正确判断你的页面到底是关于什么内容的。 也就是说，本来你期望的是用户搜索A关键词时，你的网站有排名，结果实...

### 354. No Title
- **Date:** 2024-11-11T00:20:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 要解答这个问题，我们先聊点别的。 群友 AUDI 发了一条即刻动态，说： 做SEO其实是做搜索，不是做SEO; 做搜索离不开做SEO，不只做SEO。 哥飞去补充说明了一下： SEO全称是搜索引擎优化，更正确的说法是，面向搜索引擎的需求去做网页。 发现需求，理解需求，开发产品，满足需求。 了解爬虫原理...

### 355. No Title
- **Date:** 2024-11-06T05:55:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是结果，很荣幸这个月能上榜。在ai工具赛道之后，又在游戏赛道有个好的开始。这里要先感谢哥飞和群友们的无私分享，让大家可以学到那么多的养老技能。 下面我分享一下这次拿到名次的2个站点的故事，前面大佬都分享了很多技术细节，所以我就讲故事多一点，在其中穿插说下找词、建站、上站、外链、广告、运营的...

### 356. No Title
- **Date:** 2024-11-06T00:16:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是 blank，很荣幸这次能上榜，下面给大家分享下 10 月份上新站的一些感触。我会从找词、上站、推广、变现几个部分来介绍。 先贴下 10 月份的流量情况： 一、找词 刚开始找词我是去逛游戏站、YouTube、GitHub，可以找到，但是效率很低。最近我主要是通过 Similarweb 来...

### 357. No Title
- **Date:** 2024-11-05T19:39:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是 BBQ。 没想到四个站都上榜了，非常激动，非常开心。感谢哥飞，感谢这个圈子，最后感谢我老婆！ 没错，做出这个成绩，并不是我一个人的功劳，还有我老婆的功劳。我们俩都是双双失业的程序员，她主要负责前端，我主要负责后端。 我们是怎么发现这个机会的？那还得感谢哥飞和良辰美在群里和即刻十月初左右...

### 358. No Title
- **Date:** 2024-11-05T07:23:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是Xi5h1r，这次我有两个新站分别获得了第7和第11名，注册日期为10月28日和10月20日。很高兴能和大家分享一下我的经验。 我的本职是一款安全产品的研发工程师（大家有任何网站安全相关的问题都欢迎q我），平时个人兴趣比较杂，前后端都会一点，在群里潜水小半年了，一直有关注群里的消息和哥飞...

### 359. No Title
- **Date:** 2024-10-23T04:06:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 开始之前，大家可以回顾一下之前群里聊过的游戏相关的讨论。 Wordle 填字游戏在海外火热，原版游戏被 New York Times 收购 https://web.cafe/messages/topic/987  《泰晤士报》的迷你填字游戏和 Wordle https://web.cafe/mess...

### 360. No Title
- **Date:** 2024-10-10T23:59:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是良辰美,九月份上线了好几个网站，第一个是近一周的数据， 日均2w点击左右（现在日均广告费30$，之前排第一到50k了，就是被抢了打不过对方。第二个网站数据就是过山车，后面没任何点击了。第三个网站刚开始有点数据，两个钟上线，五个钟后就收录了，五分钟内有十来个人在线。第四个站在国庆节刚开始做...

### 361. No Title
- **Date:** 2024-10-10T05:15:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 如何找新词 看谷歌趋势 把一些大类词和你观察的一些细分类别词长期放到Google Trends上，每天早上日常刷一下，看看相关查询中有没有飙升或者涨幅百分之几千的词，有的话再单独打开个Google Trends标签页，看看具体的热度情况。再去Google搜索一下这个词看看大概的情况。 对于一些具体的...

### 362. No Title
- **Date:** 2024-10-09T03:27:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 哈喽大家好，我是Lucas小杨，上个月做了个站拿到了些流量，给大家简单分享几个我自己的一些感触~ 1. 大流量 ≠ 赚大钱，更需要关注流量来源国家&需求场景本身 这次月UV 100k的网站， 实话说其实总收入还没到300美金。 因为95%以上的流量都是来自印度，剩余的也基本都是欠发达国家，上线一个月...

### 363. No Title
- **Date:** 2024-10-09T02:57:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好我是Andy，感谢哥飞教学上站，感谢大家平时在群里的分享，我也想分享下这次9月新词新站的一些心得。其实我是5月份入群，这是第一次做新词，拿到流量也有很大运气成分，但我尽量总结出我觉得合理的、大家可迁移复用的一些点。如果有说错或者有疑问的地方，大家可以交流。 一. 挖掘新词 挖掘方式：我挖掘新词...

### 364. No Title
- **Date:** 2024-10-07T18:36:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 每次上线新网站，获取外链都是一大难题。 现在社群里的朋友们做的网站也有一两千个了，我在想是否可以我们内部消化一下外链。 如果你愿意在你的网站里给群友加链接，请在本帖回复，注意需要隐藏信息。 格式如下： 网站类型：（如AI图片站） 域名DR值：42 （需要附上 Ahrefs 查出来的数据截图） 9月访...

### 365. No Title
- **Date:** 2024-08-20T06:56:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 发外链，有一个可复制的办法： 在 toolify.ai 和 theresanaiforthat.com 找到跟你的产品类似的产品，尽可能的多找一些。 去 Semrush 一个一个查这些产品的外链，到处外链域名列表。 把所有的外链域名列表汇总到一起，按照出现次数从高到低排序。 你就得到了一个绝大多数网...

### 366. No Title
- **Date:** 2024-08-13T00:33:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家听过哥飞无数次在群里说，有些关键词，别人靠内页，就能够拿到排名，如果我们做一个网站专门做这个关键词，举全站之力去优化这个关键词，那么假以时日，我们的网站也能够拿到排名，甚至超过那些内页，拿下第一名都是有可能的。 方法是什么呢？ 什么是举全站之力呢？ 这跟内页和内链又有什么关系呢？ 这就是今天要跟...

### 367. No Title
- **Date:** 2024-08-12T23:35:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞，一个自称为SEO专家的出海AI工具创业者。 我在2007年开始学编程就是​从做网站开始的，也是从那个时候开始学习搞SEO，到现在断断续续搞了1​6年了。 以前主要做百度SEO流量，最近转战谷歌，因为做谷歌就意味着可以面向70亿人做产品，为全球70亿人服务，赚​全世界人民的美元。 今...

### 368. No Title
- **Date:** 2024-08-12T19:50:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞，微信号 qiayue ，今天跟大家聊一下网站站内优化到部署上线再到推广运营一条龙，争取一篇文章让你学明白。 看这篇文章之前，需要先看前一篇挖掘需求的文章《出海工具网站，如何从需求挖掘到网站制作全流程》。 一、站内优化经验 我们通过分析需求，找到了我们可以做的关键词之后，就要思考，用...

### 369. No Title
- **Date:** 2024-08-12T19:40:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 最初 nofollow 链接的确是用来告诉搜索引擎，不要传递权重。 后来谷歌发现，交易的链接都是 dofollow 的，反倒是很多用户自发传播的链接是 nofollow ，于是修改了算法， nofollow 链接对于权重的提升也有作用了。 所以我们现在去搞外链，不要只追求 dofollow 外链， ...

### 370. No Title
- **Date:** 2024-08-12T19:23:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞，微信号 qiayue，今天给大家聊聊一个出海工具网站，如何从需求挖掘到网站制作全流程，让你一篇文章学会。 今天给大家带来的分享主要分为四个部分： 一、海外工具站的发展前景 二、怎么挖掘需求 三、实战一下挖掘需求 四、怎么制作工具站 一、海外工具站的发展前景 我们先说一下海外工具站的...

### 371. No Title
- **Date:** 2024-08-12T18:02:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞。 其实之前哥飞写过类似话题《只要行动，就会有收获；只有行动，才会有收获！》。 今天跟社群里的一位朋友聊天，说到他的某个网站，现在已经有每天10个左右的订单了。 虽然哥飞一直叫大家赶紧上站，但其实哥飞也有注册了域名还没上站的，所以今天我们再聊下这个话题。 朋友这个域名是半年前注册的，...

### 372. No Title
- **Date:** 2024-08-12T06:04:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 刚才用下面三句话回答一位群里朋友的问题，也分享给大家 title 和 h1 等页面关键词确保你的网页能够进入关键词搜索的待排名范围里； 外链帮助你进入谷歌搜索前10位置； 网站体验帮助你确定最终的名次。...

### 373. No Title
- **Date:** 2024-08-12T03:16:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** （题图，我的网站Adsense收入截图） 7月8日，哥飞受邀参加了刀姐组织的广州线下聚会，这是我在聚会上的分享，现在根据录音整理成文字版本分享给大家。 请大家先记住一个关键概念：流量思维。 我们创建网站的目的是从搜索引擎吸引流量，制作视频号或抖音账号是为了从推荐系统获取流量。你在 Instagram...

### 374. No Title
- **Date:** 2024-08-12T02:58:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞。 最近哥飞发现一个现象，好多知识哥飞讲出来了，但是每个读者看到后，理解都不太一样，这主要受限于读者本身的经验和知识，最终执行起来就会有变形。 同样的，对于一篇文章，如果我们只想知道个大概，那么用GPT总结一下没问题，但如果你想进一步学习，还是要去看原文。 GPT总结有两个问题： 1...

### 375. No Title
- **Date:** 2024-08-12T02:54:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞。 今天“哥飞的朋友们”社群里有位朋友发了下面这张截图： 哥飞去查了下，找到了原文： https://firstpagesage.com/seo-blog/the-google-algorithm-ranking-factors/ 这篇文章讲的是2024年谷歌搜索结果算法排名因素，大...

### 376. No Title
- **Date:** 2024-08-12T02:49:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 正文开始 话说，下午 MoneyHunter 群主在群里例行分享财富信息，说 BaiRBIE.me 单月访问量480万了，而且是凭空冒出来的。 我查了一下，这个域名居然是7月17日注册的，再查 archive 发现网页是7月22日被收录的，也就是说，建站到今天，也才20天。 从上图可以看出来，实际流...

### 377. No Title
- **Date:** 2024-08-12T02:21:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞。 今天是第一期，哥飞点评一下前两天在《【哥飞推荐】一个开源AI贴纸生成器，同时也是》介绍过的AI贴纸生成网站 StickerBaker.com 。 这个网站的代码是开源的，如果大家想要部署，可以看上面这篇文章。 下面我们先看下网站首页，中规中矩，很典型的AI工具站的布局，从上到下依...

### 378. No Title
- **Date:** 2024-08-12T02:02:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞。 今天给大家推荐一款特别好用而且还免费的SEO谷歌浏览器插件，这个插件哥飞每天都会使用，完全离不开了。 特别说明，今天这篇文章是哥飞自发主动写的，没有收任何推广费用。 插件用途是查看任意网页的SEO信息，方便判断网页站内优化做得好不好。 这个插件需求其实来自于哥飞，最早哥飞使用 D...

### 379. No Title
- **Date:** 2024-08-12T01:52:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞。 前天开始，哥飞带着大家读 SearchEngineJournal.com 上的文章：https://www.searchenginejournal.com/important-tags-seo/156440/ 10个标签已经介绍了6个了： 《【哥飞带你读】你需要了解的10个重要S...

### 380. No Title
- **Date:** 2024-08-12T01:46:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞。 紧接着昨天的文章，我们今天继续讲几个重要的SEO元标签。 今天哥飞带着大家读一下 SearchEngineJournal.com 上的文章：https://www.searchenginejournal.com/important-tags-seo/156440/ 我是哥飞，公众...

### 381. No Title
- **Date:** 2024-08-12T01:22:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞。 Ahrefs 做了好多免费 SEO 工具： Free Keyword Generator 免费关键词生成器 Amazon Keyword Tool 亚马逊关键词工具 Bing Keyword Tool Bing 关键词工具 YouTube Keyword Tool YouTube...

### 382. No Title
- **Date:** 2024-08-12T01:11:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 之前哥飞聊的都是关于还没上线的网站要怎么做SEO，今天哥飞跟大家聊聊，对于已经上线正在运营的网站，如何给出SEO改造建议。 进行SEO改造一般都会对网站进行改版，那么首先一个大原则就是，已经存在的URL不要做任何改动。 这是因为已经存在的URL，都被搜索引擎收录了，所以不能改。 还有很多内页已经被传...

### 383. No Title
- **Date:** 2024-08-11T23:44:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞。 话说今天哥飞去看了 Character.ai 的流量，吓一跳，都这么高了，每月1.75亿访问量了。 如果看流量曲线会发现，这还是因为最近几个月流量下降了一些，之前月访问量超过了2亿。 那么大家肯定会好奇，这么多访问量，都在访问哪些页面呢？都是什么需求呢？ 哥飞今天就带大家挖一挖。...

### 384. No Title
- **Date:** 2024-08-11T23:40:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞。 今天教大家使用 Semrush 的流量分析功能来挖掘正在赚钱的需求。 先介绍下 Gumroad ，这是一个海外虚拟产品销售平台，卖家简单设置就可以得到一个链接，然后到处去宣传推广，别人从链接点进去，就能够购买产品。 我们先看下 Gumroad 的流量数据，打开 Similarwe...

### 385. No Title
- **Date:** 2024-08-11T23:00:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞。 养网站防老系列哥飞已经更新了10篇文章了： 养网站防老：网站可以做成一生的事业 养网站防老第1步，挖掘出第1个需求 养网站防老第2步：分析搜索意图 养网站防老第1.5步：用一个公式来判断关键词是否值得做，让你选择关键词不再犹豫 养网站防老第3步：根据搜索意图使用ChatGPT的G...

### 386. No Title
- **Date:** 2024-08-11T22:52:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞。 昨天的文章我们已经把网站上线了，今天说一下上线之后我们要做的操作。 照旧，先来列出养网站防老系列的所有文章： 养网站防老：网站可以做成一生的事业 养网站防老第1步，挖掘出第1个需求 养网站防老第2步：分析搜索意图 养网站防老第1.5步：用一个公式来判断关键词是否值得做，让你选择关...

### 387. No Title
- **Date:** 2024-08-11T18:34:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞。 昨天给大家分享了《做网站没灵感？来看看别人的优秀案例之前端工具站 》，里边第2个案例如下： 2、脑力训练小游戏 humanbenchmark.com 这个网站提供了一系列的脑力小游戏给大家玩，月访问量190万，平均停留时间217秒。域名注册于2006年，archive 中能够查到...

### 388. No Title
- **Date:** 2024-07-23T22:51:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 今天的哥飞小课堂 聊聊一些大家目前用得上的广告指标。 广告曝光 你的广告被展示出来了，展示一次算一个曝光。 广告点击 有人看到了你的广告，点击了广告，打开了你的网页，就是一次广告点击。 我们设置广告时，需要设置我们愿意出的每次点击最高单价。 一般实际广告点击单价费用都不会超过我们设置的最高单价，但也...

### 389. No Title
- **Date:** 2024-07-20T23:59:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 站之初，筛词库，怼布局， 注释：建站之初，优先用semrush/ahrefs筛选词库，先做容易的词，把词库导出来进行归类，布局到整个网站的各个页面上。 看收录，收录稳，上初链， 注释：网站上线后，提交google console，然后首先要关注的是网站收录变化情况，观察自然收录的变化，如果稳定增长，...

### 390. No Title
- **Date:** 2024-07-20T20:16:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 哥飞为了看一个 mp3 文件的 metadata，就去谷歌搜索 mp3 file info checker ，结果如下。 哥飞在结果列表，右键打开了前两个结果。 因为第二个结果是后打开的，于是自然而然先看了第二个页面，结果发现是一个桌面端软件，需要下载才能使用。 于是关闭了上面这个页面，此时，第一个...

### 391. No Title
- **Date:** 2024-07-17T01:43:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 9月2日更新，开始收集大家的网站了，这个活动属于命题作文，限定关键词上站，所以就不用隐藏自己的网站了，大家直接把自己网站域名和排名发到评论区即可。 看到一组词： ai anime generator ai anime art generator anime ai art generator anim...

### 392. No Title
- **Date:** 2024-07-16T06:01:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞，今天给大家聊聊一个出海工具网站，如何从需求挖掘到网站制作全流程，让你一篇文章学会。 今天给大家带来的分享主要分为四个部分： 一、海外工具站的发展前景 二、怎么挖掘需求 三、实战一下挖掘需求 四、怎么制作工具站 一、海外工具站的发展前景 我们先说一下海外工具站的发展前景。 工具站做好...

### 393. No Title
- **Date:** 2024-07-15T23:12:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 最近群里有位朋友做了个试验，注册了几百个域名，一一建站，最后都给自己的主站加外链，结果主站很快就被谷歌惩罚了。 群友只是想着说，是否可以自己做网站来给自己加外链。 但如果换一个思路，自己注册主站核心关键词外的小词域名，然后用这些小词域名拿下排名，获取流量，最后导入到主站，那是没问题的。 具体怎么导入...

### 394. No Title
- **Date:** 2024-07-11T08:40:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 终于知道什么是刷提交量了，我这种新手前端，改个字也提交一次，直接把git变成ftp了哈... 不过还是有点成就感的，等下一阶段有成就了，再回来看一眼。 为了能更全面的介绍每一款AI 工具产品，重构了http://AllinAI.tools 的详情页，增加了section 与 pages，感谢哥飞的A...

### 395. No Title
- **Date:** 2024-07-11T08:26:00.000Z
- **Author:** undefined
- **ID:** undefined
- **Snippet:** 大家好，我是哥飞。 六月中旬开始断断续续基于 Woy.ai 的代码去继续开发，增加社区功能，终于在7月12日上线了一个版本，先把之前三次线下聚会的视频放出来给大家看。 其他功能还在开发中，还可能有不完善的地方，还请大家见谅。 我对整个社区的是这样规划的： 1、帖子 人人都能发帖回帖，通过标签来对帖子...

